import { Moon, Sun, Bell, ChevronLeft } from "lucide-react"
import { Button } from "@/components/ui/button"
import { useTheme } from "@/components/theme-provider"
import { Badge } from "@/components/ui/badge"

interface TopBarProps {
  title?: string
  showBack?: boolean
  onBack?: () => void
  showNotifications?: boolean
  transparent?: boolean
}

export function TopBar({
  title,
  showBack,
  onBack,
  showNotifications = false,
  transparent = false,
}: TopBarProps) {
  const { theme, setTheme } = useTheme()

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  return (
    <header
      className={`sticky top-0 z-50 flex items-center justify-between px-4 py-3 ${
        transparent
          ? "bg-transparent"
          : "bg-background/90 backdrop-blur-md border-b border-border/60"
      }`}
    >
      <div className="flex items-center gap-3 min-w-0">
        {showBack && (
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={onBack}
            className="rounded-xl text-muted-foreground hover:text-foreground shrink-0"
          >
            <ChevronLeft className="size-5" />
          </Button>
        )}

        {title ? (
          <h1 className="text-base font-semibold truncate text-foreground">
            {title}
          </h1>
        ) : (
          <div className="flex items-center gap-2">
            <IlahiLogoMark />
            <span
              className="ilahi-wordmark text-2xl font-bold tracking-wide"
              style={{ fontFamily: "var(--font-display)" }}
            >
              ILAHI
            </span>
            <Badge
              variant="outline"
              className="text-[9px] px-1.5 py-0 h-4 border-terracotta text-terracotta font-semibold tracking-widest uppercase"
            >
              Beta
            </Badge>
          </div>
        )}
      </div>

      <div className="flex items-center gap-1 shrink-0">
        {showNotifications && (
          <Button
            variant="ghost"
            size="icon-sm"
            className="rounded-xl relative text-muted-foreground"
          >
            <Bell className="size-4" />
            <span className="absolute top-1.5 right-1.5 size-1.5 rounded-full bg-terracotta" />
          </Button>
        )}

        <Button
          variant="ghost"
          size="icon-sm"
          onClick={toggleTheme}
          className="rounded-xl text-muted-foreground hover:text-foreground"
          aria-label="Toggle theme"
        >
          {theme === "dark" ? (
            <Sun className="size-4" />
          ) : (
            <Moon className="size-4" />
          )}
        </Button>
      </div>
    </header>
  )
}

function IlahiLogoMark() {
  return (
    <div className="size-7 rounded-lg bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center shrink-0">
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
        {/* Stylized kite / compass rose — hint of Gujarat kite festival */}
        <path d="M8 1 L10.5 6.5 L8 8 L5.5 6.5 Z" fill="white" opacity="0.9"/>
        <path d="M8 8 L13.5 7 L15 9.5 L8 8 Z" fill="white" opacity="0.6"/>
        <path d="M8 8 L2.5 7 L1 9.5 L8 8 Z" fill="white" opacity="0.6"/>
        <path d="M8 8 L10 12.5 L8 15 L6 12.5 Z" fill="white" opacity="0.8"/>
      </svg>
    </div>
  )
}
