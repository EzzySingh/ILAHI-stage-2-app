import { Home, Compass, CalendarCheck, Shield, User } from "lucide-react"
import { cn } from "@/lib/utils"

export type PageId = "home" | "explore" | "bookings" | "safety" | "profile"

interface BottomNavProps {
  active: PageId
  onNavigate: (page: PageId) => void
}

const items: { id: PageId; label: string; icon: typeof Home }[] = [
  { id: "home", label: "Home", icon: Home },
  { id: "explore", label: "Explore", icon: Compass },
  { id: "bookings", label: "Bookings", icon: CalendarCheck },
  { id: "safety", label: "Safety", icon: Shield },
  { id: "profile", label: "Profile", icon: User },
]

export function BottomNav({ active, onNavigate }: BottomNavProps) {
  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 z-50 w-full max-w-[480px] px-3 pb-3 pt-1 bg-gradient-to-t from-background via-background/95 to-background/0 backdrop-blur-sm">
      <div className="flex items-center justify-around rounded-2xl border border-border/60 bg-card/80 backdrop-blur-md px-1.5 py-1.5 shadow-lg">
        {items.map((item) => {
          const Icon = item.icon
          const isActive = active === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "flex flex-col items-center gap-0.5 rounded-xl px-3 py-1.5 transition-all press-effect",
                isActive
                  ? "text-terracotta"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              <Icon
                className={cn("size-5 transition-transform", isActive && "scale-110")}
                strokeWidth={isActive ? 2.5 : 2}
              />
              <span
                className={cn(
                  "text-[10px] font-medium tracking-wide",
                  isActive && "font-semibold"
                )}
              >
                {item.label}
              </span>
              {isActive && (
                <span className="absolute -bottom-0.5 h-0.5 w-6 rounded-full bg-terracotta" />
              )}
            </button>
          )
        })}
      </div>
    </nav>
  )
}
