import { useState, useEffect } from "react"
import { HomePage } from "@/pages/HomePage"
import { ExplorePage } from "@/pages/ExplorePage"
import { CityDetailPage } from "@/pages/CityDetailPage"
import { MatchPage } from "@/pages/MatchPage"
import { BookingPage } from "@/pages/BookingPage"
import { BookingsPage } from "@/pages/BookingsPage"
import { SafetyPage } from "@/pages/SafetyPage"
import { ProfilePage } from "@/pages/ProfilePage"
import { BottomNav, type PageId } from "@/components/ilahi/BottomNav"
import { GuideAuthPage } from "@/pages/guide/GuideAuthPage"
import { GuideRegisterPage } from "@/pages/guide/GuideRegisterPage"
import { GuideSuccessPage } from "@/pages/guide/GuideSuccessPage"
import { GuideProfileEditPage } from "@/pages/guide/GuideProfileEditPage"
import { GuideDashboardPage } from "@/pages/guide/GuideDashboardPage"
import { useAuth } from "@/lib/auth-context"
import { supabase, type GuideProfile } from "@/lib/supabase"

type TouristView =
  | { type: "tab"; page: PageId }
  | { type: "city"; cityId: string }
  | { type: "match"; cityId?: string }
  | { type: "booking" }
  | { type: "safety-detail" }

type GuideView =
  | { type: "guide-auth" }
  | { type: "guide-register" }
  | { type: "guide-success" }
  | { type: "guide-edit" }
  | { type: "guide-dashboard" }

type View = TouristView | GuideView

export function App() {
  const { user, loading, signOut } = useAuth()
  const [view, setView] = useState<View>({ type: "tab", page: "home" })
  const [guideProfile, setGuideProfile] = useState<GuideProfile | null>(null)
  const [checkingGuide, setCheckingGuide] = useState(false)

  // When entering guide portal, check if user already has a profile
  useEffect(() => {
    if (user && (view.type === "guide-auth" || view.type === "guide-register")) {
      setCheckingGuide(true)
      supabase
        .from("guide_profiles")
        .select("*")
        .eq("user_id", user.id)
        .maybeSingle()
        .then(({ data }) => {
          if (data) {
            setGuideProfile(data as GuideProfile)
            setView({ type: "guide-dashboard" })
          } else if (view.type === "guide-auth") {
            setView({ type: "guide-register" })
          }
          setCheckingGuide(false)
        })
    }
  }, [user, view.type])

  const activeTab: PageId =
    view.type === "tab" ? view.page : view.type === "booking" ? "bookings" : "home"

  const goHome = () => setView({ type: "tab", page: "home" })

  const handleSignOut = async () => {
    await signOut()
    setGuideProfile(null)
    setView({ type: "tab", page: "home" })
  }

  // Guide portal views
  if (view.type === "guide-auth") {
    if (loading || checkingGuide) return <LoadingScreen />
    return (
      <div className="app-frame bg-background">
        <GuideAuthPage
          onAuthed={() => {
            // useEffect will detect user and check for existing profile
          }}
          onBack={goHome}
        />
      </div>
    )
  }

  if (view.type === "guide-register") {
    return (
      <div className="app-frame bg-background">
        <GuideRegisterPage
          onRegistered={(profile) => {
            setGuideProfile(profile)
            setView({ type: "guide-success" })
          }}
          onBack={goHome}
        />
      </div>
    )
  }

  if (view.type === "guide-success" && guideProfile) {
    return (
      <div className="app-frame bg-background">
        <GuideSuccessPage
          profile={guideProfile}
          onComplete={() => setView({ type: "guide-dashboard" })}
          onAddMore={() => setView({ type: "guide-edit" })}
        />
      </div>
    )
  }

  if (view.type === "guide-edit" && guideProfile) {
    return (
      <div className="app-frame bg-background">
        <GuideProfileEditPage
          profile={guideProfile}
          onSaved={(updated) => {
            setGuideProfile(updated)
            setView({ type: "guide-dashboard" })
          }}
          onBack={() => setView({ type: "guide-dashboard" })}
        />
      </div>
    )
  }

  if (view.type === "guide-dashboard") {
    return (
      <div className="app-frame bg-background">
        <GuideDashboardPage
          onEdit={() => setView({ type: "guide-edit" })}
          onSignOut={handleSignOut}
        />
      </div>
    )
  }

  // Tourist app views
  return (
    <div className="app-frame bg-background">
      {view.type === "tab" && view.page === "home" && (
        <HomePage
          onNavigate={(page) => setView({ type: "tab", page })}
          onSelectCity={(cityId) => setView({ type: "city", cityId })}
          onStartMatch={() => setView({ type: "match" })}
        />
      )}

      {view.type === "tab" && view.page === "explore" && (
        <ExplorePage onSelectCity={(cityId) => setView({ type: "city", cityId })} />
      )}

      {view.type === "tab" && view.page === "bookings" && (
        <BookingsPage
          onStartMatch={() => setView({ type: "match" })}
          onGoSafety={() => setView({ type: "safety-detail" })}
        />
      )}

      {view.type === "tab" && view.page === "safety" && <SafetyPage />}

      {view.type === "tab" && view.page === "profile" && (
        <ProfilePage onBecomeGuide={() => setView({ type: "guide-auth" })} />
      )}

      {view.type === "city" && (
        <CityDetailPage
          cityId={view.cityId}
          onBack={() => setView({ type: "tab", page: "explore" })}
          onStartMatch={(cityId) => setView({ type: "match", cityId })}
        />
      )}

      {view.type === "match" && (
        <MatchPage
          cityId={view.cityId}
          onBack={goHome}
          onMatchComplete={() => setView({ type: "booking" })}
        />
      )}

      {view.type === "booking" && (
        <BookingPage
          onBack={goHome}
          onComplete={() => setView({ type: "tab", page: "bookings" })}
        />
      )}

      {view.type === "safety-detail" && (
        <SafetyPage onBack={() => setView({ type: "tab", page: "bookings" })} />
      )}

      {/* Hide bottom nav on booking/match/city flows */}
      {view.type !== "booking" && view.type !== "match" && view.type !== "city" && (
        <BottomNav
          active={activeTab}
          onNavigate={(page) => setView({ type: "tab", page })}
        />
      )}
    </div>
  )
}

function LoadingScreen() {
  return (
    <div className="app-frame bg-background flex items-center justify-center min-h-svh">
      <div className="size-8 rounded-full border-2 border-terracotta/30 border-t-terracotta animate-spin" />
    </div>
  )
}

export default App
