import { useState, useRef, useEffect } from "react"
import { Loader2, Upload, Check, Clock, MapPin, Tag, FileText, Shield } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { supabase, type GuideProfile } from "@/lib/supabase"
import { cities } from "@/lib/data/cities"
import { useAuth } from "@/lib/auth-context"

interface GuideProfileEditPageProps {
  profile: GuideProfile
  onSaved: (updated: GuideProfile) => void
  onBack: () => void
}

const SPECIALTY_OPTIONS = [
  "Heritage Walks",
  "Food Trails",
  "Craft & Textiles",
  "Wildlife & Nature",
  "Pilgrimage & Temples",
  "Photography",
  "Adventure & Trekking",
  "Beaches & Coast",
  "Festivals & Culture",
  "Nightlife & Street Food",
  "Architecture",
  "Local Markets",
]

const AVAILABILITY_PRESETS = [
  { id: "weekday_mornings", label: "Weekday Mornings", desc: "Mon–Fri, 7 AM – 12 PM" },
  { id: "weekends", label: "Weekends", desc: "Sat & Sun, full day" },
  { id: "flexible", label: "Flexible", desc: "Available most days" },
]

const DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]

export function GuideProfileEditPage({ profile, onSaved, onBack }: GuideProfileEditPageProps) {
  const { user } = useAuth()
  const [specialties, setSpecialties] = useState<string[]>(profile.specialties ?? [])
  const [areas, setAreas] = useState<string[]>(profile.areas_of_expertise ?? [])
  const [bio, setBio] = useState(profile.bio ?? "")
  const [availabilityPreset, setAvailabilityPreset] = useState(profile.availability_preset ?? "flexible")
  const [showCustom, setShowCustom] = useState(false)
  const [customSlots, setCustomSlots] = useState<{ day: number; start: string; end: string }[]>([])
  const [credentialFile, setCredentialFile] = useState<File | null>(null)
  const [credentialStatus, setCredStatus] = useState<string>(profile.credential_url ? "uploaded" : "none")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (availabilityPreset === "custom") setShowCustom(true)
  }, [availabilityPreset])

  const toggleSpecialty = (s: string) => {
    setSpecialties((prev) =>
      prev.includes(s) ? prev.filter((x) => x !== s) : [...prev, s]
    )
  }

  const toggleArea = (a: string) => {
    setAreas((prev) =>
      prev.includes(a) ? prev.filter((x) => x !== a) : [...prev, a]
    )
  }

  const handleCredential = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!["application/pdf", "image/jpeg", "image/png"].includes(file.type)) {
      setError("Credentials must be PDF, JPG, or PNG")
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("File must be under 5MB")
      return
    }
    setError(null)
    setCredentialFile(file)
  }

  const handleSave = async () => {
    setLoading(true)
    setError(null)

    let credentialUrl = profile.credential_url

    if (credentialFile && user) {
      const ext = credentialFile.name.split(".").pop()
      const path = `${user.id}/credential-${Date.now()}.${ext}`
      const { error: uploadError } = await supabase.storage
        .from("guide-credentials")
        .upload(path, credentialFile, { contentType: credentialFile.type })

      if (uploadError) {
        setError("Credential upload failed: " + uploadError.message)
        setLoading(false)
        return
      }
      credentialUrl = path
      setCredStatus("uploaded")
    }

    const updateData: Record<string, unknown> = {
      specialties: specialties.length > 0 ? specialties : null,
      areas_of_expertise: areas.length > 0 ? areas : null,
      bio: bio.trim() || null,
      availability_preset: availabilityPreset,
      credential_url: credentialUrl,
    }

    const { data, error: updateError } = await supabase
      .from("guide_profiles")
      .update(updateData)
      .eq("id", profile.id)
      .select()
      .maybeSingle()

    if (updateError) {
      setError("Save failed: " + updateError.message)
      setLoading(false)
      return
    }

    if (customSlots.length > 0 && data) {
      await supabase
        .from("guide_availability")
        .delete()
        .eq("guide_id", profile.id)

      const slots = customSlots.map((s) => ({
        guide_id: profile.id,
        day_of_week: s.day,
        start_time: s.start,
        end_time: s.end,
        is_active: true,
      }))

      await supabase
        .from("guide_availability")
        .insert(slots)
    }

    setLoading(false)
    if (data) onSaved(data as GuideProfile)
    else onSaved({ ...profile, ...updateData } as GuideProfile)
  }

  const livePct = (() => {
    let pct = 0
    if (bio.trim()) pct += 25
    if (specialties.length > 0) pct += 25
    if (areas.length > 0) pct += 25
    if (credentialFile || profile.credential_url) pct += 25
    return pct
  })()

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Complete Profile" showBack onBack={onBack} />

      <div className="px-5 pt-4 space-y-5">
        {/* Live completion bar */}
        <Card className="border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold">Live Completion</span>
              <span
                className="text-lg font-bold text-terracotta"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {livePct}%
              </span>
            </div>
            <Progress value={livePct} className="h-2.5" />
          </CardContent>
        </Card>

        {/* Specialties */}
        <Section icon={Tag} title="Your Specialties" hint="Pick what you know best">
          <div className="flex flex-wrap gap-2">
            {SPECIALTY_OPTIONS.map((s) => {
              const selected = specialties.includes(s)
              return (
                <button
                  key={s}
                  onClick={() => toggleSpecialty(s)}
                  className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all press-effect ${
                    selected
                      ? "bg-terracotta text-terracotta-foreground"
                      : "bg-muted text-muted-foreground hover:bg-accent"
                  }`}
                >
                  {selected && <Check className="size-3 inline mr-1" />}
                  {s}
                </button>
              )
            })}
          </div>
        </Section>

        {/* Areas of expertise */}
        <Section icon={MapPin} title="Areas of Expertise" hint="Neighborhoods/localities you know well">
          <div className="flex flex-wrap gap-2">
            {cities.map((c) => {
              const selected = areas.includes(c.name)
              return (
                <button
                  key={c.id}
                  onClick={() => toggleArea(c.name)}
                  className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all press-effect ${
                    selected
                      ? "bg-indigo-bandhani text-indigo-bandhani-foreground"
                      : "bg-muted text-muted-foreground hover:bg-accent"
                  }`}
                >
                  {selected && <Check className="size-3 inline mr-1" />}
                  {c.name}
                </button>
              )
            })}
          </div>
        </Section>

        {/* Availability */}
        <Section icon={Clock} title="Availability" hint="When can you guide?">
          <div className="space-y-2">
            {AVAILABILITY_PRESETS.map((preset) => (
              <button
                key={preset.id}
                onClick={() => {
                  setAvailabilityPreset(preset.id)
                  setShowCustom(false)
                }}
                className={`w-full flex items-center gap-3 rounded-xl border p-3 text-left transition-all press-effect ${
                  availabilityPreset === preset.id
                    ? "border-terracotta bg-terracotta/10"
                    : "border-border/60 bg-card hover:bg-accent"
                }`}
              >
                <div
                  className={`size-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                    availabilityPreset === preset.id ? "border-terracotta bg-terracotta" : "border-muted-foreground/30"
                  }`}
                >
                  {availabilityPreset === preset.id && <div className="size-2 rounded-full bg-white" />}
                </div>
                <div>
                  <p className="text-sm font-medium">{preset.label}</p>
                  <p className="text-[11px] text-muted-foreground">{preset.desc}</p>
                </div>
              </button>
            ))}

            <button
              onClick={() => {
                setAvailabilityPreset("custom")
                setShowCustom(true)
                if (customSlots.length === 0) {
                  setCustomSlots([{ day: 1, start: "09:00", end: "17:00" }])
                }
              }}
              className={`w-full flex items-center gap-3 rounded-xl border p-3 text-left transition-all press-effect ${
                availabilityPreset === "custom"
                  ? "border-terracotta bg-terracotta/10"
                  : "border-border/60 bg-card hover:bg-accent"
              }`}
            >
              <div
                className={`size-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                  availabilityPreset === "custom" ? "border-terracotta bg-terracotta" : "border-muted-foreground/30"
                }`}
              >
                {availabilityPreset === "custom" && <div className="size-2 rounded-full bg-white" />}
              </div>
              <div>
                <p className="text-sm font-medium">Customize</p>
                <p className="text-[11px] text-muted-foreground">Set specific days and times</p>
              </div>
            </button>

            {showCustom && (
              <div className="space-y-2 mt-2 animate-reveal-up">
                {customSlots.map((slot, idx) => (
                  <div key={idx} className="flex items-center gap-2 rounded-lg bg-muted/50 p-2">
                    <select
                      value={slot.day}
                      onChange={(e) => {
                        const updated = [...customSlots]
                        updated[idx] = { ...slot, day: Number(e.target.value) }
                        setCustomSlots(updated)
                      }}
                      className="text-xs rounded-md border border-border bg-card px-2 py-1.5"
                    >
                      {DAYS.map((d, i) => (
                        <option key={i} value={i}>{d}</option>
                      ))}
                    </select>
                    <input
                      type="time"
                      value={slot.start}
                      onChange={(e) => {
                        const updated = [...customSlots]
                        updated[idx] = { ...slot, start: e.target.value }
                        setCustomSlots(updated)
                      }}
                      className="text-xs rounded-md border border-border bg-card px-2 py-1.5"
                    />
                    <span className="text-xs text-muted-foreground">to</span>
                    <input
                      type="time"
                      value={slot.end}
                      onChange={(e) => {
                        const updated = [...customSlots]
                        updated[idx] = { ...slot, end: e.target.value }
                        setCustomSlots(updated)
                      }}
                      className="text-xs rounded-md border border-border bg-card px-2 py-1.5"
                    />
                    <button
                      onClick={() => setCustomSlots(customSlots.filter((_, i) => i !== idx))}
                      className="text-xs text-destructive px-1"
                    >
                      ✕
                    </button>
                  </div>
                ))}
                <button
                  onClick={() => setCustomSlots([...customSlots, { day: 1, start: "09:00", end: "17:00" }])}
                  className="text-xs text-terracotta font-medium"
                >
                  + Add another slot
                </button>
              </div>
            )}
          </div>
        </Section>

        {/* Bio */}
        <Section icon={FileText} title="About You" hint="A short intro for travelers">
          <Textarea
            placeholder="Tell travelers about yourself — what makes you the right local for them..."
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={500}
            className="min-h-24"
          />
          <p className="text-[10px] text-muted-foreground text-right mt-1">
            {bio.length}/500
          </p>
        </Section>

        {/* Credentials */}
        <Section icon={Shield} title="Credentials" hint="ID or certificate for verification (private)">
          <button
            onClick={() => fileRef.current?.click()}
            className="w-full flex items-center gap-3 rounded-xl border-2 border-dashed border-border p-4 text-left hover:border-terracotta transition-all press-effect"
          >
            <div className="size-10 rounded-lg bg-muted flex items-center justify-center shrink-0">
              {credentialStatus === "uploaded" ? (
                <Check className="size-5 text-terracotta" />
              ) : (
                <Upload className="size-5 text-muted-foreground" />
              )}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">
                {credentialStatus === "uploaded"
                  ? "Credential uploaded"
                  : "Upload ID / Certificate"}
              </p>
              <p className="text-[11px] text-muted-foreground">
                {credentialStatus === "uploaded"
                  ? "Pending admin review"
                  : "PDF, JPG, or PNG — max 5MB. Never shown publicly."}
              </p>
            </div>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,image/jpeg,image/png"
            onChange={handleCredential}
            className="hidden"
          />
          {profile.is_verified && (
            <Badge variant="outline" className="mt-2 border-terracotta text-terracotta">
              <Check className="size-3 mr-1" />
              Verified
            </Badge>
          )}
        </Section>

        {error && (
          <p className="text-xs text-destructive bg-destructive/10 rounded-lg px-3 py-2">
            {error}
          </p>
        )}

        <Button
          onClick={handleSave}
          disabled={loading}
          className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
          size="lg"
        >
          {loading ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <>
              <Check className="size-4" />
              Save Profile
            </>
          )}
        </Button>
        <div className="h-2" />
      </div>
    </div>
  )
}

function Section({
  icon: Icon,
  title,
  hint,
  children,
}: {
  icon: typeof Tag
  title: string
  hint: string
  children: React.ReactNode
}) {
  return (
    <div>
      <div className="flex items-center gap-2 mb-2">
        <div className="size-7 rounded-lg bg-terracotta/15 flex items-center justify-center">
          <Icon className="size-4 text-terracotta" />
        </div>
        <div>
          <h3
            className="text-sm font-semibold"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {title}
          </h3>
          <p className="text-[11px] text-muted-foreground">{hint}</p>
        </div>
      </div>
      {children}
    </div>
  )
}
