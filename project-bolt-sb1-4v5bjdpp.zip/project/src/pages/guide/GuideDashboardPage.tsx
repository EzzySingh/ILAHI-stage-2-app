import { useState, useEffect } from "react"
import { Loader2, Shield, Check, MapPin, Clock, Tag, LogOut, Pencil, Star, Eye } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { supabase, type GuideProfile } from "@/lib/supabase"
import { useAuth } from "@/lib/auth-context"

interface GuideDashboardPageProps {
  onEdit: () => void
  onSignOut: () => void
}

export function GuideDashboardPage({ onEdit, onSignOut }: GuideDashboardPageProps) {
  const { user } = useAuth()
  const [profile, setProfile] = useState<GuideProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return
    supabase
      .from("guide_profiles")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data, error }) => {
        if (!error && data) setProfile(data as GuideProfile)
        setLoading(false)
      })
  }, [user])

  if (loading) {
    return (
      <div className="bottom-nav-pad">
        <TopBar title="Guide Dashboard" />
        <div className="flex items-center justify-center pt-20">
          <Loader2 className="size-6 animate-spin text-terracotta" />
        </div>
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="bottom-nav-pad">
        <TopBar title="Guide Dashboard" />
        <div className="px-5 pt-10 text-center">
          <p className="text-sm text-muted-foreground">No profile found.</p>
        </div>
      </div>
    )
  }

  const pct = profile.profile_completion_pct ?? 0

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Guide Dashboard" />

      <div className="px-5 pt-4 space-y-4">
        {/* Profile header */}
        <Card className="border-border/60 overflow-hidden">
          <div className="h-20 bg-gradient-to-br from-terracotta to-saffron relative">
            <div className="absolute inset-0 bandhani-pattern opacity-30" />
          </div>
          <CardContent className="-mt-10 relative">
            <div className="flex items-end gap-3">
              <div className="size-16 rounded-2xl bg-gradient-to-br from-indigo-bandhani to-terracotta border-4 border-card flex items-center justify-center text-xl font-bold text-white shrink-0" style={{ fontFamily: "var(--font-display)" }}>
                {profile.full_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div className="flex-1 pb-1">
                <div className="flex items-center gap-1.5">
                  <h3
                    className="text-lg font-bold"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {profile.full_name}
                  </h3>
                  {profile.is_verified ? (
                    <Badge variant="outline" className="border-terracotta text-terracotta text-[9px]">
                      <Check className="size-2.5 mr-0.5" />
                      Verified
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="text-[9px] text-muted-foreground">
                      <Clock className="size-2.5 mr-0.5" />
                      Pending
                    </Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                  <MapPin className="size-3" />
                  {profile.primary_area}
                </p>
              </div>
            </div>

            {profile.bio && (
              <p className="text-sm text-foreground/80 mt-3 leading-relaxed">
                {profile.bio}
              </p>
            )}

            {/* Completion bar */}
            <div className="mt-3">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-medium text-muted-foreground">Profile Completion</span>
                <span
                  className="text-sm font-bold text-terracotta"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {pct}%
                </span>
              </div>
              <Progress value={pct} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-2">
          <StatBox icon={Star} value="0" label="Trips" />
          <StatBox icon={Eye} value="0" label="Views" />
          <StatBox icon={Shield} value={profile.is_verified ? "Yes" : "No"} label="Verified" />
        </div>

        {/* Specialties */}
        {profile.specialties && profile.specialties.length > 0 && (
          <Card className="border-border/60">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <Tag className="size-4 text-terracotta" />
                <h4
                  className="text-sm font-semibold"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Specialties
                </h4>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {profile.specialties.map((s) => (
                  <Badge key={s} variant="secondary" className="text-[10px]">
                    {s}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Areas of expertise */}
        {profile.areas_of_expertise && profile.areas_of_expertise.length > 0 && (
          <Card className="border-border/60">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-2">
                <MapPin className="size-4 text-indigo-bandhani" />
                <h4
                  className="text-sm font-semibold"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Areas of Expertise
                </h4>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {profile.areas_of_expertise.map((a) => (
                  <Badge key={a} variant="outline" className="text-[10px]">
                    {a}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Availability */}
        <Card className="border-border/60">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="size-4 text-terracotta" />
              <h4
                className="text-sm font-semibold"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Availability
              </h4>
            </div>
            <p className="text-sm text-muted-foreground capitalize">
              {profile.availability_preset.replace(/_/g, " ")}
            </p>
          </CardContent>
        </Card>

        {/* Privacy info */}
        <div className="rounded-xl bg-gradient-to-br from-indigo-bandhani/10 to-terracotta/10 border border-border/60 p-3.5">
          <div className="flex gap-2.5 items-start">
            <Shield className="size-4 text-terracotta mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium">Your privacy is protected</p>
              <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">
                Your phone number and credentials are never shown publicly. Only your name, photo, specialties, and bio are visible to travelers.
              </p>
            </div>
          </div>
        </div>

        {/* Actions */}
        <Button
          onClick={onEdit}
          className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
          size="lg"
        >
          <Pencil className="size-4" />
          Edit Profile
        </Button>

        <Button
          onClick={onSignOut}
          variant="outline"
          className="w-full press-effect"
          size="lg"
        >
          <LogOut className="size-4" />
          Sign Out
        </Button>

        <div className="h-2" />
      </div>
    </div>
  )
}

function StatBox({ icon: Icon, value, label }: { icon: typeof Star; value: string; label: string }) {
  return (
    <div className="rounded-xl border border-border/60 bg-card p-3 text-center">
      <Icon className="size-4 text-muted-foreground mx-auto mb-1" />
      <div
        className="text-lg font-bold text-foreground"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</div>
    </div>
  )
}
