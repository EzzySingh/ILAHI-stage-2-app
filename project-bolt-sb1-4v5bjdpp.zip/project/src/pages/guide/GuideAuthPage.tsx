import { useState } from "react"
import { Compass, Loader2, Mail, Lock, UserPlus, LogIn } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { useAuth } from "@/lib/auth-context"

interface GuideAuthPageProps {
  onAuthed: () => void
  onBack: () => void
}

export function GuideAuthPage({ onAuthed, onBack }: GuideAuthPageProps) {
  const { signIn, signUp } = useAuth()
  const [mode, setMode] = useState<"signin" | "signup">("signup")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setLoading(true)

    const result = mode === "signup"
      ? await signUp(email, password)
      : await signIn(email, password)

    setLoading(false)

    if (result.error) {
      setError(result.error)
    } else {
      onAuthed()
    }
  }

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Guide Portal" showBack onBack={onBack} />

      <div className="px-5 pt-6">
        <div className="text-center mb-6">
          <div className="size-14 rounded-2xl bg-gradient-to-br from-indigo-bandhani to-terracotta flex items-center justify-center mx-auto mb-3">
            <Compass className="size-7 text-white" />
          </div>
          <h2
            className="text-xl font-bold"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Become a Local Guide
          </h2>
          <p className="text-sm text-muted-foreground mt-1.5 max-w-[280px] mx-auto">
            Share your knowledge of Gujarat with travelers. Earn from your local expertise.
          </p>
        </div>

        <Card className="border-border/60">
          <CardContent className="p-4">
            {/* Mode toggle */}
            <div className="flex rounded-lg bg-muted p-1 mb-4">
              <button
                onClick={() => setMode("signup")}
                className={`flex-1 rounded-md py-2 text-sm font-medium transition-all ${
                  mode === "signup"
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground"
                }`}
              >
                Sign Up
              </button>
              <button
                onClick={() => setMode("signin")}
                className={`flex-1 rounded-md py-2 text-sm font-medium transition-all ${
                  mode === "signin"
                    ? "bg-card text-foreground shadow-sm"
                    : "text-muted-foreground"
                }`}
              >
                Sign In
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3">
              <div>
                <label className="text-sm font-medium mb-1.5 block">Email</label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    type="email"
                    placeholder="you@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="pl-9"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="text-sm font-medium mb-1.5 block">Password</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
                  <Input
                    type="password"
                    placeholder="Min 6 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pl-9"
                    minLength={6}
                    required
                  />
                </div>
              </div>

              {error && (
                <p className="text-xs text-destructive bg-destructive/10 rounded-lg px-3 py-2">
                  {error}
                </p>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
                size="lg"
              >
                {loading ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : mode === "signup" ? (
                  <>
                    <UserPlus className="size-4" />
                    Create Account
                  </>
                ) : (
                  <>
                    <LogIn className="size-4" />
                    Sign In
                  </>
                )}
              </Button>
            </form>

            <p className="text-[11px] text-muted-foreground text-center mt-3">
              {mode === "signup"
                ? "Already have an account? "
                : "New to ILAHI? "}
              <button
                onClick={() => setMode(mode === "signup" ? "signin" : "signup")}
                className="text-terracotta font-medium"
              >
                {mode === "signup" ? "Sign in" : "Create one"}
              </button>
            </p>
          </CardContent>
        </Card>

        <p className="text-[11px] text-muted-foreground text-center mt-4 max-w-[280px] mx-auto">
          Your phone number and credentials are never shown publicly. Only your name, photo, and specialties appear to travelers.
        </p>
      </div>
    </div>
  )
}
