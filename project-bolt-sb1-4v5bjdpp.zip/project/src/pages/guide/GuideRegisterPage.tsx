import { useState, useRef } from "react"
import { Camera, Loader2, Check, Phone, MapPin, User } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import { NativeSelect, NativeSelectOption } from "@/components/ui/native-select"
import { cities } from "@/lib/data/cities"
import { supabase, type GuideProfile } from "@/lib/supabase"
import { useAuth } from "@/lib/auth-context"

interface GuideRegisterPageProps {
  onRegistered: (profile: GuideProfile) => void
  onBack: () => void
}

const PHONE_REGEX = /^[+]?[0-9]{10,13}$/

export function GuideRegisterPage({ onRegistered, onBack }: GuideRegisterPageProps) {
  const { user } = useAuth()
  const [fullName, setFullName] = useState("")
  const [phone, setPhone] = useState("")
  const [primaryArea, setPrimaryArea] = useState("")
  const [photoFile, setPhotoFile] = useState<File | null>(null)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)

  const handlePhoto = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!["image/jpeg", "image/png"].includes(file.type)) {
      setError("Photo must be JPG or PNG")
      return
    }
    if (file.size > 5 * 1024 * 1024) {
      setError("Photo must be under 5MB")
      return
    }
    setError(null)
    setPhotoFile(file)
    setPhotoPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    if (!fullName.trim()) {
      setError("Please enter your full name")
      return
    }
    if (!PHONE_REGEX.test(phone.replace(/\s/g, ""))) {
      setError("Enter a valid phone number (10-13 digits)")
      return
    }
    if (!primaryArea) {
      setError("Select your primary area")
      return
    }
    if (!user) {
      setError("Not signed in — please go back and sign in")
      return
    }

    setLoading(true)

    let photoUrl: string | null = null

    if (photoFile) {
      const ext = photoFile.name.split(".").pop()
      const path = `${user.id}/profile-${Date.now()}.${ext}`
      const { error: uploadError } = await supabase.storage
        .from("guide-photos")
        .upload(path, photoFile, { contentType: photoFile.type })

      if (uploadError) {
        setError("Photo upload failed: " + uploadError.message)
        setLoading(false)
        return
      }

      const { data: urlData } = supabase.storage
        .from("guide-photos")
        .getPublicUrl(path)
      photoUrl = urlData.publicUrl
    }

    const { data, error: insertError } = await supabase
      .from("guide_profiles")
      .insert({
        full_name: fullName.trim(),
        phone: phone.trim(),
        primary_area: primaryArea,
        photo_url: photoUrl,
      })
      .select()
      .maybeSingle()

    if (insertError) {
      setError("Registration failed: " + insertError.message)
      setLoading(false)
      return
    }

    if (!data) {
      setError("Could not create profile — please try again")
      setLoading(false)
      return
    }

    setLoading(false)
    onRegistered(data as GuideProfile)
  }

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Guide Signup" showBack onBack={onBack} />

      <div className="px-5 pt-4">
        <div className="text-center mb-5">
          <h2
            className="text-xl font-bold"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Quick Registration
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            You'll be live in under 2 minutes. Complete your profile anytime later.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Photo upload */}
          <div className="flex flex-col items-center mb-2">
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              className="size-24 rounded-2xl border-2 border-dashed border-border flex items-center justify-center overflow-hidden press-effect transition-all hover:border-terracotta"
            >
              {photoPreview ? (
                <img src={photoPreview} alt="Profile" className="size-full object-cover" />
              ) : (
                <div className="flex flex-col items-center gap-1 text-muted-foreground">
                  <Camera className="size-6" />
                  <span className="text-[10px]">Add photo</span>
                </div>
              )}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png"
              onChange={handlePhoto}
              className="hidden"
            />
            <p className="text-[10px] text-muted-foreground mt-1.5">JPG or PNG, max 5MB</p>
          </div>

          {/* Full name */}
          <div>
            <label className="text-sm font-medium mb-1.5 block">Full Name</label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="Your name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* Phone */}
          <div>
            <label className="text-sm font-medium mb-1.5 block">Phone Number</label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
              <Input
                placeholder="+91 98XXX XXXXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="pl-9"
                inputMode="tel"
              />
            </div>
            <p className="text-[10px] text-muted-foreground mt-1">
              Never shown publicly — only shared after a confirmed booking
            </p>
          </div>

          {/* Primary area */}
          <div>
            <label className="text-sm font-medium mb-1.5 block">Primary Area</label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground z-10" />
              <NativeSelect
                value={primaryArea}
                onChange={(e) => setPrimaryArea(e.target.value)}
                className="pl-9 w-full"
              >
                <NativeSelectOption value="" disabled>
                  Select your city
                </NativeSelectOption>
                {cities.map((c) => (
                  <NativeSelectOption key={c.id} value={c.name}>
                    {c.name} — {c.region}
                  </NativeSelectOption>
                ))}
              </NativeSelect>
            </div>
          </div>

          {error && (
            <p className="text-xs text-destructive bg-destructive/10 rounded-lg px-3 py-2">
              {error}
            </p>
          )}

          <Button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
            size="lg"
          >
            {loading ? (
              <Loader2 className="size-4 animate-spin" />
            ) : (
              <>
                <Check className="size-4" />
                Go Live
              </>
            )}
          </Button>
        </form>

        <Card className="border-border/60 mt-4">
          <CardContent className="p-3.5">
            <p className="text-xs text-muted-foreground leading-relaxed">
              By registering, you agree to ILAHI's guide verification process. Your
              profile will be reviewed by our team before it's fully verified.
              You can start receiving match requests immediately.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
