import { Check, Sparkles, ArrowRight } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import type { GuideProfile } from "@/lib/supabase"

interface GuideSuccessPageProps {
  profile: GuideProfile
  onComplete: () => void
  onAddMore: () => void
}

export function GuideSuccessPage({ profile, onComplete, onAddMore }: GuideSuccessPageProps) {
  const pct = profile.profile_completion_pct ?? 0

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Welcome" />

      <div className="px-5 pt-6">
        <div className="flex flex-col items-center text-center mb-5">
          <div className="size-20 rounded-full bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center animate-reveal-scale">
            <Check className="size-9 text-white" strokeWidth={3} />
          </div>
          <h2
            className="text-xl font-bold mt-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            You're Live!
          </h2>
          <p className="text-sm text-muted-foreground mt-1.5 max-w-[280px]">
            Your guide profile is now discoverable by travelers visiting {profile.primary_area}.
          </p>
        </div>

        {/* Profile summary */}
        <Card className="border-border/60 mb-4 overflow-hidden">
          <div className="h-16 bg-gradient-to-br from-terracotta to-saffron relative">
            <div className="absolute inset-0 bandhani-pattern opacity-30" />
          </div>
          <CardContent className="-mt-8 relative">
            <div className="flex items-end gap-3">
              <div className="size-14 rounded-2xl bg-gradient-to-br from-indigo-bandhani to-terracotta border-4 border-card flex items-center justify-center text-lg font-bold text-white shrink-0" style={{ fontFamily: "var(--font-display)" }}>
                {profile.full_name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
              </div>
              <div className="flex-1 pb-1">
                <h3
                  className="text-base font-bold"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {profile.full_name}
                </h3>
                <p className="text-xs text-muted-foreground">{profile.primary_area}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Completion bar */}
        <Card className="border-border/60 mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold">Profile Completion</span>
              <span
                className="text-lg font-bold text-terracotta"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {pct}%
              </span>
            </div>
            <Progress value={pct} className="h-2.5" />
            <p className="text-[11px] text-muted-foreground mt-2">
              {pct < 100
                ? "Complete your profile to get more match requests and higher visibility."
                : "Your profile is complete! You're fully optimized for discovery."}
            </p>
          </CardContent>
        </Card>

        {/* What's next */}
        <div className="space-y-2.5 mb-5">
          <NextStep
            done={pct >= 25}
            text="Add your specialties (heritage walks, food trails, etc.)"
          />
          <NextStep
            done={pct >= 50}
            text="List areas of expertise within your city"
          />
          <NextStep
            done={pct >= 75}
            text="Write a short bio so travelers get to know you"
          />
          <NextStep
            done={pct >= 100}
            text="Upload credentials for verification"
          />
        </div>

        <Button
          onClick={onAddMore}
          className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect mb-2"
          size="lg"
        >
          <Sparkles className="size-4" />
          Complete Profile Now
        </Button>
        <Button
          onClick={onComplete}
          variant="outline"
          className="w-full press-effect"
          size="lg"
        >
          Go to Dashboard
          <ArrowRight className="size-4" />
        </Button>
      </div>
    </div>
  )
}

function NextStep({ done, text }: { done: boolean; text: string }) {
  return (
    <div className="flex items-center gap-2.5">
      <div
        className={`size-5 rounded-full flex items-center justify-center shrink-0 ${
          done ? "bg-terracotta" : "border-2 border-muted-foreground/30"
        }`}
      >
        {done && <Check className="size-3 text-white" strokeWidth={3} />}
      </div>
      <span className={`text-sm ${done ? "text-muted-foreground line-through" : "text-foreground"}`}>
        {text}
      </span>
    </div>
  )
}
