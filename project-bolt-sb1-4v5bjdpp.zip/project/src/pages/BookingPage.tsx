import { useState } from "react"
import { Shield, Check, Loader2, Lock, QrCode, ArrowRight, Wallet, Vault } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

interface BookingPageProps {
  onBack: () => void
  onComplete: () => void
}

type Stage = "upi" | "confirm" | "processing" | "escrow" | "done"

export function BookingPage({ onBack, onComplete }: BookingPageProps) {
  const [stage, setStage] = useState<Stage>("upi")
  const [upiId, setUpiId] = useState("")
  const [showQR, setShowQR] = useState(false)
  const [escrowStep, setEscrowStep] = useState(0)

  const amount = 9000

  const handlePay = () => {
    setStage("processing")
    setTimeout(() => {
      setStage("escrow")
      setTimeout(() => setEscrowStep(1), 800)
      setTimeout(() => setEscrowStep(2), 2000)
      setTimeout(() => setStage("done"), 3500)
    }, 2500)
  }

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Booking & Payment" showBack onBack={onBack} />

      <div className="px-5 pt-4">
        {/* Progress bar */}
        <div className="flex items-center gap-1.5 mb-5">
          {["Payment", "Escrow", "Confirmed"].map((label, i) => {
            const stepActive =
              (stage === "upi" || stage === "confirm" || stage === "processing") && i === 0 ||
              (stage === "escrow") && i <= 1 ||
              (stage === "done") && i <= 2
            return (
              <div key={label} className="flex-1">
                <div
                  className={`h-1.5 rounded-full transition-all ${
                    stepActive ? "bg-terracotta" : "bg-muted"
                  }`}
                />
                <span
                  className={`text-[9px] mt-1 block text-center ${
                    stepActive ? "text-terracotta font-semibold" : "text-muted-foreground"
                  }`}
                >
                  {label}
                </span>
              </div>
            )
          })}
        </div>

        {/* UPI Payment */}
        {(stage === "upi" || stage === "confirm") && (
          <div className="animate-reveal-up">
            <Card className="border-border/60 overflow-hidden">
              <div className="h-16 bg-gradient-to-br from-indigo-bandhani to-terracotta relative">
                <div className="absolute inset-0 bandhani-pattern opacity-30" />
                <div className="absolute inset-0 flex items-center px-4">
                  <div>
                    <p className="text-[10px] text-white/70 uppercase tracking-wide">Trip Total</p>
                    <p
                      className="text-2xl font-bold text-white"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      ₹{amount.toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
              <CardContent className="p-4">
                {/* Trust badge */}
                <div className="flex items-center gap-2 rounded-lg upi-secure-badge px-3 py-2 mb-4">
                  <Shield className="size-4 text-white" />
                  <span className="text-xs text-white font-medium">
                    Protected by ILAHI Escrow Vault
                  </span>
                </div>

                {!showQR ? (
                  <>
                    <label className="text-sm font-semibold mb-2 block">Enter UPI ID</label>
                    <Input
                      placeholder="yourname@upi"
                      value={upiId}
                      onChange={(e) => setUpiId(e.target.value)}
                      className="mb-3"
                    />
                    <button
                      onClick={() => setShowQR(true)}
                      className="text-xs text-terracotta font-medium flex items-center gap-1"
                    >
                      <QrCode className="size-3.5" />
                      Scan QR code instead
                    </button>
                  </>
                ) : (
                  <div className="flex flex-col items-center py-2">
                    <div className="size-44 rounded-xl border-2 border-border bg-white p-3 flex items-center justify-center">
                      {/* Mock QR pattern */}
                      <div className="grid grid-cols-8 gap-0.5 w-full h-full">
                        {Array.from({ length: 64 }).map((_, i) => (
                          <div
                            key={i}
                            className={`rounded-sm ${
                              (i * 7 + i * 3) % 3 === 0 ? "bg-foreground" : "bg-transparent"
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-3 text-center">
                      Scan with any UPI app to pay ₹{amount.toLocaleString()}
                    </p>
                    <button
                      onClick={() => setShowQR(false)}
                      className="text-xs text-terracotta font-medium mt-2"
                    >
                      Enter UPI ID instead
                    </button>
                  </div>
                )}

                {stage === "upi" && (
                  <Button
                    onClick={() => setStage("confirm")}
                    disabled={!showQR && upiId.length < 5}
                    className="w-full mt-4 bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
                    size="lg"
                  >
                    <Lock className="size-4" />
                    Proceed to Pay ₹{amount.toLocaleString()}
                  </Button>
                )}

                {stage === "confirm" && (
                  <div className="mt-4 space-y-3 animate-reveal-up">
                    <div className="rounded-lg bg-muted/50 p-3 text-sm">
                      <div className="flex justify-between mb-1">
                        <span className="text-muted-foreground">Paying to</span>
                        <span className="font-medium">{showQR ? "ILAHI Escrow" : upiId}</span>
                      </div>
                      <div className="flex justify-between mb-1">
                        <span className="text-muted-foreground">Amount</span>
                        <span className="font-medium">₹{amount.toLocaleString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Held in</span>
                        <span className="font-medium text-terracotta">Escrow Vault</span>
                      </div>
                    </div>
                    <Button
                      onClick={handlePay}
                      className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
                      size="lg"
                    >
                      <Shield className="size-4" />
                      Confirm & Pay Securely
                    </Button>
                    <p className="text-[11px] text-muted-foreground text-center">
                      Your payment is held safely. Released to your local only after your trip.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Processing */}
        {stage === "processing" && (
          <div className="flex flex-col items-center justify-center pt-16 animate-reveal-up">
            <div className="size-16 rounded-full bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center">
              <Loader2 className="size-7 text-white animate-spin" />
            </div>
            <h3
              className="text-lg font-bold mt-5"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Processing payment...
            </h3>
            <p className="text-sm text-muted-foreground mt-2 text-center max-w-[240px]">
              Securing your payment in the ILAHI Escrow Vault.
            </p>
          </div>
        )}

        {/* Escrow flow */}
        {stage === "escrow" && (
          <div className="animate-reveal-up">
            <h3
              className="text-lg font-bold text-center mb-4"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Escrow Vault Status
            </h3>

            <div className="space-y-3">
              <EscrowStep
                icon={Wallet}
                title="Payment Received"
                desc="₹9,000 received from your UPI account"
                state={escrowStep >= 0 ? "done" : "pending"}
              />
              <EscrowArrow active={escrowStep >= 1} />
              <EscrowStep
                icon={Vault}
                title="Held in Escrow"
                desc="Funds secured — your local is notified"
                state={escrowStep >= 1 ? "active" : "pending"}
                pulse={escrowStep === 1}
              />
              <EscrowArrow active={escrowStep >= 2} />
              <EscrowStep
                icon={ArrowRight}
                title="Released to Host"
                desc="Funds released after trip completion"
                state={escrowStep >= 2 ? "done" : "pending"}
              />
            </div>

            <div className="mt-5 rounded-xl bg-terracotta/10 border border-terracotta/30 p-3.5">
              <div className="flex gap-2.5 items-start">
                <Shield className="size-4 text-terracotta mt-0.5 shrink-0" />
                <div>
                  <p className="text-sm font-medium text-terracotta">
                    {escrowStep < 2 ? "Your money is protected" : "Trip confirmed!"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {escrowStep < 2
                      ? "Funds stay in escrow until you complete your trip. Your local gets paid only after."
                      : "Your booking is fully confirmed. Your local has been notified and is preparing."}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Done */}
        {stage === "done" && (
          <div className="flex flex-col items-center justify-center pt-12 animate-reveal-up">
            <div className="size-20 rounded-full bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center animate-reveal-scale">
              <Check className="size-9 text-white" strokeWidth={3} />
            </div>
            <h3
              className="text-xl font-bold mt-5"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Booking Confirmed!
            </h3>
            <p className="text-sm text-muted-foreground mt-2 text-center max-w-[260px]">
              Your trip is booked and your payment is safely held in escrow. Your local has been notified.
            </p>

            <Card className="w-full mt-5 border-border/60">
              <CardContent className="p-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Booking ID</span>
                  <span className="font-mono font-medium">ILH-2026-0142</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-medium">₹{amount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Status</span>
                  <Badge variant="outline" className="border-terracotta text-terracotta">
                    <Vault className="size-3 mr-1" />
                    In Escrow
                  </Badge>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={onComplete}
              className="w-full mt-4 bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
              size="lg"
            >
              View My Trip
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

function EscrowStep({
  icon: Icon,
  title,
  desc,
  state,
  pulse,
}: {
  icon: typeof Wallet
  title: string
  desc: string
  state: "pending" | "active" | "done"
  pulse?: boolean
}) {
  return (
    <div
      className={`flex gap-3 items-start rounded-xl border p-3.5 transition-all ${
        state === "done"
          ? "border-terracotta/40 bg-terracotta/5"
          : state === "active"
            ? "border-terracotta bg-terracotta/10"
            : "border-border/60 bg-muted/30"
      } ${pulse ? "animate-escrow-pulse" : ""}`}
    >
      <div
        className={`size-10 rounded-xl flex items-center justify-center shrink-0 ${
          state === "done"
            ? "bg-terracotta text-white"
            : state === "active"
              ? "bg-terracotta/20 text-terracotta"
              : "bg-muted text-muted-foreground"
        }`}
      >
        {state === "done" ? (
          <Check className="size-5" strokeWidth={3} />
        ) : (
          <Icon className="size-5" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <h4 className="text-sm font-semibold">{title}</h4>
        <p className="text-xs text-muted-foreground mt-0.5">{desc}</p>
      </div>
    </div>
  )
}

function EscrowArrow({ active }: { active: boolean }) {
  return (
    <div className="flex justify-center">
      <div
        className={`w-0.5 h-4 ${active ? "bg-terracotta" : "bg-muted-foreground/20"}`}
      />
    </div>
  )
}
