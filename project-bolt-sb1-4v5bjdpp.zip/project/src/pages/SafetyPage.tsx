import { useState } from "react"
import { Shield, AlertTriangle, Share2, Phone, MapPin, Check, Users, Eye, X } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"

interface SafetyPageProps {
  onBack?: () => void
}

export function SafetyPage({ onBack }: SafetyPageProps) {
  const [sosActive, setSosActive] = useState(false)
  const [shareEnabled, setShareEnabled] = useState(true)
  const [trustedContacts] = useState([
    { name: "Mom", phone: "+91 98XXX XXX12", status: "active" },
    { name: "Rohan (Brother)", phone: "+91 98XXX XXX87", status: "active" },
  { name: "Priya (Friend)", phone: "+91 98XXX XXX45", status: "pending" },
  ])

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Trip Safety" showBack={onBack ? true : false} onBack={onBack} />

      <div className="px-5 pt-4">
        {/* Live trip banner */}
        <Card className="border-terracotta/40 mb-4 overflow-hidden">
          <div className="h-2 bg-gradient-to-r from-terracotta to-saffron" />
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-1">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-terracotta opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-terracotta" />
              </span>
              <span className="text-xs font-bold uppercase tracking-wide text-terracotta">
                Trip in Progress
              </span>
            </div>
            <h3
              className="text-base font-bold"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Ahmedabad with Meera
            </h3>
            <p className="text-xs text-muted-foreground mt-0.5">Day 1 of 3 · Started 2 hours ago</p>

            <div className="flex items-center gap-2 mt-3 rounded-lg bg-muted/50 p-2.5">
              <MapPin className="size-4 text-terracotta shrink-0" />
              <span className="text-xs text-muted-foreground">
                Last location: Manek Chowk, Ahmedabad
              </span>
              <span className="text-[10px] text-muted-foreground/60 ml-auto">2 min ago</span>
            </div>
          </CardContent>
        </Card>

        {/* SOS Button */}
        <div className="flex flex-col items-center mb-5">
          <button
            onClick={() => setSosActive(!sosActive)}
            className={`size-28 rounded-full flex flex-col items-center justify-center transition-all press-effect ${
              sosActive
                ? "bg-destructive text-white animate-beacon-pulse"
                : "bg-gradient-to-br from-destructive to-terracotta text-white"
            }`}
          >
            <AlertTriangle className="size-8" />
            <span className="text-sm font-bold mt-1">
              {sosActive ? "SOS ACTIVE" : "SOS"}
            </span>
            <span className="text-[9px] opacity-80">
              {sosActive ? "Tap to cancel" : "Tap for help"}
            </span>
          </button>
          <p className="text-xs text-muted-foreground mt-3 text-center max-w-[240px]">
            {sosActive
              ? "Alert sent to trusted contacts and ILAHI support. Stay calm — help is on the way."
              : "Press to instantly alert your trusted contacts and ILAHI's 24/7 support team."}
          </p>
          {sosActive && (
            <div className="mt-3 flex gap-2 animate-reveal-up">
              <Button variant="outline" size="sm" className="border-destructive/40 text-destructive">
                <Phone className="size-3.5" />
                Call 112
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSosActive(false)}
              >
                <X className="size-3.5" />
                Cancel SOS
              </Button>
            </div>
          )}
        </div>

        {/* Live trip sharing */}
        <div className="mb-4">
          <h3
            className="text-sm font-semibold mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Live Trip Sharing
          </h3>
          <Card className="border-border/60">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="size-9 rounded-lg bg-terracotta/15 flex items-center justify-center">
                    <Share2 className="size-4 text-terracotta" />
                  </div>
                  <div>
                    <p className="text-sm font-medium">Share live location</p>
                    <p className="text-[11px] text-muted-foreground">With 3 trusted contacts</p>
                  </div>
                </div>
                <button
                  onClick={() => setShareEnabled(!shareEnabled)}
                  className={`w-11 h-6 rounded-full transition-colors ${
                    shareEnabled ? "bg-terracotta" : "bg-muted"
                  } relative`}
                >
                  <span
                    className={`absolute top-0.5 size-5 rounded-full bg-white transition-transform ${
                      shareEnabled ? "translate-x-5" : "translate-x-0.5"
                    }`}
                  />
                </button>
              </div>

              {shareEnabled && (
                <div className="space-y-2 mt-3 pt-3 border-t border-border/60">
                  {trustedContacts.map((contact) => (
                    <div
                      key={contact.name}
                      className="flex items-center gap-2.5"
                    >
                      <div className="size-8 rounded-full bg-gradient-to-br from-indigo-bandhani to-terracotta flex items-center justify-center text-xs font-bold text-white">
                        {contact.name[0]}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium">{contact.name}</p>
                        <p className="text-[10px] text-muted-foreground">{contact.phone}</p>
                      </div>
                      {contact.status === "active" ? (
                        <Badge variant="outline" className="border-terracotta/40 text-terracotta text-[9px]">
                          <Check className="size-2.5 mr-0.5" />
                          Tracking
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[9px] text-muted-foreground">
                          Pending
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Safety features */}
        <div className="mb-4">
          <h3
            className="text-sm font-semibold mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Safety Features
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <SafetyFeatureCard
              icon={Users}
              title="Verified Locals"
              desc="ID & background checked"
            />
            <SafetyFeatureCard
              icon={Shield}
              title="Escrow Protected"
              desc="Funds held securely"
            />
            <SafetyFeatureCard
              icon={Eye}
              title="24/7 Monitoring"
              desc="ILAHI support team"
            />
            <SafetyFeatureCard
              icon={Phone}
              title="Emergency Hotline"
              desc="One-tap calling"
            />
          </div>
        </div>

        {/* Safety tips */}
        <div className="rounded-xl bg-gradient-to-br from-indigo-bandhani/10 to-terracotta/10 border border-border/60 p-4">
          <h4
            className="text-sm font-semibold mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Gujarat Travel Safety Tips
          </h4>
          <ul className="space-y-1.5 text-xs text-muted-foreground">
            <li className="flex gap-2">
              <span className="text-terracotta">·</span>
              Gujarat is dry state — no alcohol is legal. Respect local customs.
            </li>
            <li className="flex gap-2">
              <span className="text-terracotta">·</span>
              Dress modestly at religious sites — shoulders and knees covered.
            </li>
            <li className="flex gap-2">
              <span className="text-terracotta">·</span>
              Carry cash in rural Kutch — UPI coverage is patchy outside cities.
            </li>
            <li className="flex gap-2">
              <span className="text-terracotta">·</span>
              Check tide tables before coastal excursions (Dwarka, Diu).
            </li>
            <li className="flex gap-2">
              <span className="text-terracotta">·</span>
              Share your live trip with family — it's free and always on.
            </li>
          </ul>
        </div>
      </div>
    </div>
  )
}

function SafetyFeatureCard({
  icon: Icon,
  title,
  desc,
}: {
  icon: typeof Shield
  title: string
  desc: string
}) {
  return (
    <div className="rounded-xl border border-border/60 bg-card p-3 card-hover">
      <div className="size-9 rounded-lg bg-terracotta/15 flex items-center justify-center mb-2">
        <Icon className="size-4 text-terracotta" />
      </div>
      <h4 className="text-xs font-semibold">{title}</h4>
      <p className="text-[10px] text-muted-foreground mt-0.5">{desc}</p>
    </div>
  )
}
