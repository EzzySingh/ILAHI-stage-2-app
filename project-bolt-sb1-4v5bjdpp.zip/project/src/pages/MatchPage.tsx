import { useState } from "react"
import { Sparkles, Heart, Star, MapPin, Check, ChevronRight, Loader2 } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { getCityById } from "@/lib/data/cities"

interface MatchPageProps {
  cityId?: string
  onBack: () => void
  onMatchComplete: (localId: string) => void
}

interface LocalHost {
  id: string
  name: string
  age: number
  bio: string
  specialties: string[]
  rating: number
  trips: number
  languages: string[]
  matchScore: number
  avatarColor: string
}

const mockLocals: LocalHost[] = [
  {
    id: "meera",
    name: "Meera Patel",
    age: 24,
    bio: "Born in the old pol. I'll take you through haveli doors my grandfather showed me. I know which Manek Chowk stall has the best dal baati at 11 PM.",
    specialties: ["Heritage Walks", "Street Food", "Festivals"],
    rating: 4.9,
    trips: 87,
    languages: ["Gujarati", "Hindi", "English"],
    matchScore: 94,
    avatarColor: "from-terracotta to-saffron",
  },
  {
    id: "arjun",
    name: "Arjun Desai",
    age: 27,
    bio: "MSU Fine Arts graduate. I'll show you Vadodara's gallery scene and the garba grounds nobody tells tourists about. Also: the best Parsi food trail.",
    specialties: ["Art & Culture", "Garba", "Food Trails"],
    rating: 4.8,
    trips: 62,
    languages: ["Gujarati", "Hindi", "English"],
    matchScore: 91,
    avatarColor: "from-indigo-bandhani to-copper",
  },
  {
    id: "fatima",
    name: "Fatima Sheikh",
    age: 22,
    bio: "Kutchi craftsperson from Bhujodi. My family weaves shawls — I'll take you to workshops where you'll see real Ajrakh printing, not a showroom.",
    specialties: ["Craft Villages", "Textile Art", "Stargazing"],
    rating: 5.0,
    trips: 43,
    languages: ["Kutchi", "Gujarati", "Hindi"],
    matchScore: 89,
    avatarColor: "from-copper to-terracotta",
  },
]

const interests = [
  "Heritage & Architecture",
  "Food & Cuisine",
  "Craft & Textiles",
  "Wildlife & Nature",
  "Pilgrimage & Spirituality",
  "Photography",
  "Adventure & Trekking",
  "Beaches & Coast",
]

export function MatchPage({ cityId, onBack, onMatchComplete }: MatchPageProps) {
  const city = cityId ? getCityById(cityId) : undefined
  const [step, setStep] = useState<"interests" | "matching" | "result">("interests")
  const [selected, setSelected] = useState<string[]>([])
  const [budget, setBudget] = useState(3000)
  const [days, setDays] = useState(3)
  const [matchedLocal] = useState<LocalHost>(mockLocals[0])

  const toggleInterest = (interest: string) => {
    setSelected((prev) =>
      prev.includes(interest)
        ? prev.filter((i) => i !== interest)
        : [...prev, interest]
    )
  }

  const startMatching = () => {
    setStep("matching")
    setTimeout(() => setStep("result"), 2800)
  }

  return (
    <div className="bottom-nav-pad">
      <TopBar
        title={city ? `Match: ${city.name}` : "Find Your Local"}
        showBack
        onBack={onBack}
      />

      {step === "interests" && (
        <div className="px-5 pt-4 animate-reveal-up">
          <div className="text-center mb-5">
            <div className="size-14 rounded-2xl bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center mx-auto mb-3">
              <Sparkles className="size-7 text-white" />
            </div>
            <h2
              className="text-xl font-bold"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Let's find your perfect local
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              Tell us what you love — our AI matches you with a verified local who shares your interests.
            </p>
          </div>

          {/* Interests */}
          <div className="mb-5">
            <label className="text-sm font-semibold mb-2 block">Your interests</label>
            <div className="grid grid-cols-2 gap-2">
              {interests.map((interest) => {
                const isSelected = selected.includes(interest)
                return (
                  <button
                    key={interest}
                    onClick={() => toggleInterest(interest)}
                    className={`flex items-center gap-2 rounded-xl border p-2.5 text-left text-xs font-medium transition-all press-effect ${
                      isSelected
                        ? "border-terracotta bg-terracotta/10 text-terracotta"
                        : "border-border/60 bg-card text-muted-foreground hover:bg-accent"
                    }`}
                  >
                    <div
                      className={`size-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                        isSelected ? "border-terracotta bg-terracotta" : "border-muted-foreground/40"
                      }`}
                    >
                      {isSelected && <Check className="size-2.5 text-white" />}
                    </div>
                    {interest}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Budget */}
          <div className="mb-5">
            <label className="text-sm font-semibold mb-2 block">
              Budget: <span className="text-terracotta">₹{budget.toLocaleString()}</span> / day
            </label>
            <input
              type="range"
              min={500}
              max={10000}
              step={500}
              value={budget}
              onChange={(e) => setBudget(Number(e.target.value))}
              className="w-full accent-terracotta"
            />
            <div className="flex justify-between text-[10px] text-muted-foreground mt-1">
              <span>₹500</span>
              <span>₹10,000</span>
            </div>
          </div>

          {/* Days */}
          <div className="mb-5">
            <label className="text-sm font-semibold mb-2 block">Trip duration</label>
            <div className="flex gap-2">
              {[1, 2, 3, 5, 7].map((d) => (
                <button
                  key={d}
                  onClick={() => setDays(d)}
                  className={`flex-1 rounded-lg py-2 text-sm font-medium transition-all press-effect ${
                    days === d
                      ? "bg-terracotta text-terracotta-foreground"
                      : "bg-muted text-muted-foreground hover:bg-accent"
                  }`}
                >
                  {d}d
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={startMatching}
            disabled={selected.length === 0}
            className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
            size="lg"
          >
            <Sparkles className="size-4" />
            Find My Match
          </Button>
          {selected.length === 0 && (
            <p className="text-[11px] text-muted-foreground text-center mt-2">
              Select at least one interest to continue
            </p>
          )}
        </div>
      )}

      {step === "matching" && (
        <div className="flex flex-col items-center justify-center px-5 pt-20 animate-reveal-up">
          <div className="relative">
            <div className="size-20 rounded-full bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center animate-beacon-pulse">
              <Loader2 className="size-8 text-white animate-spin" />
            </div>
          </div>
          <h2
            className="text-xl font-bold mt-6"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Finding your match...
          </h2>
          <p className="text-sm text-muted-foreground mt-2 text-center max-w-[260px]">
            Analyzing interests, checking local availability, and calculating compatibility scores.
          </p>
          <div className="w-full max-w-[260px] mt-6 space-y-2">
            <MatchStep label="Scoring interests" done />
            <MatchStep label="Checking verified locals" done />
            <MatchStep label="Calculating compatibility" active />
            <MatchStep label="Generating itinerary" />
          </div>
        </div>
      )}

      {step === "result" && (
        <div className="px-5 pt-4 animate-reveal-up">
          {/* Match score */}
          <div className="text-center mb-4">
            <div className="relative inline-flex items-center justify-center">
              <svg className="size-24 -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="42" fill="none" stroke="var(--muted)" strokeWidth="6" />
                <circle
                  cx="50"
                  cy="50"
                  r="42"
                  fill="none"
                  stroke="var(--terracotta)"
                  strokeWidth="6"
                  strokeDasharray={`${(matchedLocal.matchScore / 100) * 264} 264`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span
                  className="text-3xl font-bold text-terracotta"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {matchedLocal.matchScore}%
                </span>
                <span className="text-[10px] text-muted-foreground uppercase tracking-wide">Match</span>
              </div>
            </div>
            <h2
              className="text-xl font-bold mt-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              We found your local
            </h2>
          </div>

          {/* Local card */}
          <Card className="border-border/60 card-hover overflow-hidden">
            <div className={`h-20 bg-gradient-to-br ${matchedLocal.avatarColor} relative`}>
              <div className="absolute inset-0 bandhani-pattern opacity-30" />
            </div>
            <CardContent className="-mt-10 relative">
              <div className="flex items-end gap-3">
                <div
                  className={`size-16 rounded-2xl bg-gradient-to-br ${matchedLocal.avatarColor} border-4 border-card flex items-center justify-center text-2xl font-bold text-white shrink-0`}
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {matchedLocal.name.split(" ").map((n) => n[0]).join("")}
                </div>
                <div className="flex-1 pb-1">
                  <div className="flex items-center gap-1.5">
                    <Badge variant="outline" className="text-[9px] border-terracotta text-terracotta">
                      <Check className="size-2.5 mr-0.5" />
                      Verified
                    </Badge>
                  </div>
                </div>
              </div>

              <h3
                className="text-lg font-bold mt-2"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {matchedLocal.name}, {matchedLocal.age}
              </h3>
              <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                <span className="flex items-center gap-1">
                  <Star className="size-3 fill-saffron text-saffron" />
                  {matchedLocal.rating}
                </span>
                <span>{matchedLocal.trips} trips</span>
                <span className="flex items-center gap-1">
                  <MapPin className="size-3" />
                  {city?.name || "Gujarat"}
                </span>
              </div>

              <p className="text-sm text-foreground/80 mt-3 leading-relaxed">
                {matchedLocal.bio}
              </p>

              <div className="flex gap-1.5 mt-3 flex-wrap">
                {matchedLocal.specialties.map((s) => (
                  <Badge key={s} variant="secondary" className="text-[10px]">
                    {s}
                  </Badge>
                ))}
              </div>

              <div className="flex gap-1.5 mt-2 flex-wrap">
                {matchedLocal.languages.map((l) => (
                  <span key={l} className="text-[10px] text-muted-foreground">
                    · {l}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Sample itinerary preview */}
          <div className="mt-4">
            <h4
              className="text-sm font-semibold mb-2"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Your {days}-day itinerary preview
            </h4>
            <div className="space-y-2">
              {Array.from({ length: Math.min(days, 3) }).map((_, i) => (
                <div
                  key={i}
                  className="flex gap-3 rounded-xl border border-border/60 bg-card p-3 animate-stagger-in"
                  style={{ animationDelay: `${i * 100}ms` }}
                >
                  <div className="size-8 rounded-lg bg-terracotta/15 flex items-center justify-center shrink-0">
                    <span
                      className="text-sm font-bold text-terracotta"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      D{i + 1}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">
                      {["Heritage walk & local food", "Craft village & cultural deep-dive", "Hidden gems & sunset spot"][i]}
                    </p>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {["7 AM – 2 PM · Pol architecture + Manek Chowk", "9 AM – 4 PM · Bhujodi weaving + Ajrakh printing", "4 PM – 9 PM · Stepwell + rooftop sunset"][i]}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Price */}
          <div className="mt-4 rounded-xl bg-muted/50 p-4">
            <div className="flex items-baseline justify-between">
              <span className="text-sm text-muted-foreground">Estimated total</span>
              <span
                className="text-2xl font-bold text-terracotta"
                style={{ fontFamily: "var(--font-display)" }}
              >
                ₹{(budget * days).toLocaleString()}
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground mt-1">
              {days} days · ₹{budget.toLocaleString()}/day · includes local guide, experiences, and meals
            </p>
          </div>

          <Button
            onClick={() => onMatchComplete(matchedLocal.id)}
            className="w-full mt-4 bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
            size="lg"
          >
            <Heart className="size-4" />
            Book with {matchedLocal.name.split(" ")[0]}
            <ChevronRight className="size-4" />
          </Button>
          <p className="text-[11px] text-muted-foreground text-center mt-2">
            Payment held in escrow — released to your local only after trip completion
          </p>
        </div>
      )}
    </div>
  )
}

function MatchStep({ label, done, active }: { label: string; done?: boolean; active?: boolean }) {
  return (
    <div className="flex items-center gap-2 text-sm">
      {done ? (
        <div className="size-4 rounded-full bg-terracotta flex items-center justify-center">
          <Check className="size-2.5 text-white" />
        </div>
      ) : active ? (
        <Loader2 className="size-4 text-terracotta animate-spin" />
      ) : (
        <div className="size-4 rounded-full border-2 border-muted-foreground/30" />
      )}
      <span className={done || active ? "text-foreground" : "text-muted-foreground"}>
        {label}
      </span>
    </div>
  )
}
