import { useState } from "react"
import { Search, MapPin, Filter } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { cities } from "@/lib/data/cities"

interface ExplorePageProps {
  onSelectCity: (cityId: string) => void
}

const vibeFilters = [
  "All",
  "Heritage",
  "Craft",
  "Food",
  "Beaches",
  "Wildlife",
  "Pilgrimage",
  "Trekking",
  "Art",
]

export function ExplorePage({ onSelectCity }: ExplorePageProps) {
  const [query, setQuery] = useState("")
  const [activeFilter, setActiveFilter] = useState("All")

  const filtered = cities.filter((c) => {
    const matchesQuery =
      query === "" ||
      c.name.toLowerCase().includes(query.toLowerCase()) ||
      c.tagline.toLowerCase().includes(query.toLowerCase()) ||
      c.intro.toLowerCase().includes(query.toLowerCase())

    const matchesFilter =
      activeFilter === "All" || c.vibe.includes(activeFilter)

    return matchesQuery && matchesFilter
  })

  return (
    <div className="bottom-nav-pad">
      <TopBar title="Explore Gujarat" />

      <div className="px-5 pt-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="Search cities, experiences..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="pl-9"
          />
        </div>

        {/* Vibe filter chips */}
        <div className="flex gap-1.5 overflow-x-auto pb-1 mt-3 -mx-5 px-5 scrollbar-none">
          {vibeFilters.map((vibe) => (
            <button
              key={vibe}
              onClick={() => setActiveFilter(vibe)}
              className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-medium transition-all press-effect ${
                activeFilter === vibe
                  ? "bg-terracotta text-terracotta-foreground"
                  : "bg-muted text-muted-foreground hover:bg-accent"
              }`}
            >
              {vibe}
            </button>
          ))}
        </div>

        {/* Results count */}
        <p className="text-xs text-muted-foreground mt-3 mb-2">
          {filtered.length} {filtered.length === 1 ? "city" : "cities"} found
        </p>

        {/* City list */}
        <div className="space-y-3">
          {filtered.map((city, idx) => (
            <button
              key={city.id}
              onClick={() => onSelectCity(city.id)}
              className="w-full text-left animate-stagger-in press-effect"
              style={{ animationDelay: `${idx * 60}ms` }}
            >
              <div className="flex gap-3 rounded-xl border border-border/60 bg-card overflow-hidden card-hover">
                <div
                  className={`w-24 shrink-0 bg-gradient-to-br ${city.heroGradient} relative`}
                >
                  <div className="absolute inset-0 bandhani-pattern opacity-30" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-3xl">{city.hiddenGems[0].icon}</span>
                  </div>
                </div>
                <div className="flex-1 p-3 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <MapPin className="size-3 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground">{city.region}</span>
                  </div>
                  <h3
                    className="text-base font-bold leading-tight"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    {city.name}
                  </h3>
                  <p className="text-xs text-muted-foreground line-clamp-2 mt-1 leading-relaxed">
                    {city.intro}
                  </p>
                  <div className="flex gap-1 mt-2 flex-wrap">
                    {city.vibe.slice(0, 3).map((v) => (
                      <Badge key={v} variant="secondary" className="text-[9px] px-1.5 py-0">
                        {v}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </button>
          ))}

          {filtered.length === 0 && (
            <div className="text-center py-12">
              <p className="text-sm text-muted-foreground">
                No cities match your search. Try a different filter.
              </p>
              <Button
                variant="outline"
                size="sm"
                className="mt-3"
                onClick={() => {
                  setQuery("")
                  setActiveFilter("All")
                }}
              >
                <Filter className="size-3.5" />
                Reset filters
              </Button>
            </div>
          )}
        </div>
      </div>

      <div className="h-4" />
    </div>
  )
}
