import { Vault, MapPin, Calendar, Star, ChevronRight, Sparkles } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface BookingsPageProps {
  onStartMatch: () => void
  onGoSafety: () => void
}

export function BookingsPage({ onStartMatch, onGoSafety }: BookingsPageProps) {
  return (
    <div className="bottom-nav-pad">
      <TopBar title="My Bookings" />

      <div className="px-5 pt-4">
        {/* Active booking */}
        <div className="mb-5">
          <h2
            className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3"
          >
            Active Trip
          </h2>

          <Card className="border-terracotta/40 overflow-hidden card-hover">
            <div className="h-20 bg-gradient-to-br from-terracotta to-saffron relative">
              <div className="absolute inset-0 bandhani-pattern opacity-30" />
              <div className="absolute inset-0 flex items-center justify-between px-4">
                <div>
                  <Badge
                    variant="outline"
                    className="border-white/30 text-white bg-white/10 backdrop-blur-sm"
                  >
                    <Vault className="size-3 mr-1" />
                    In Escrow
                  </Badge>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-white/70 uppercase">Trip ID</p>
                  <p className="text-sm font-mono text-white">ILH-2026-0142</p>
                </div>
              </div>
            </div>
            <CardContent className="p-4">
              <div className="flex gap-3 items-start">
                <div className="size-12 rounded-xl bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center text-lg font-bold text-white shrink-0" style={{ fontFamily: "var(--font-display)" }}>
                  MP
                </div>
                <div className="flex-1 min-w-0">
                  <h3
                    className="text-base font-bold"
                    style={{ fontFamily: "var(--font-display)" }}
                  >
                    Meera Patel
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                    <span className="flex items-center gap-1">
                      <Star className="size-3 fill-saffron text-saffron" />
                      4.9
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="size-3" />
                      Ahmedabad
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
                <Calendar className="size-3.5 text-terracotta" />
                <span>Sep 18 – Sep 20, 2026 · 3 days</span>
              </div>

              {/* Escrow status */}
              <div className="mt-3 rounded-lg bg-terracotta/10 border border-terracotta/20 p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Vault className="size-4 text-terracotta" />
                    <span className="text-xs font-medium text-terracotta">₹9,000 in Escrow</span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">Released after trip</span>
                </div>
              </div>

              <Button
                onClick={onGoSafety}
                className="w-full mt-3 bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
                size="lg"
              >
                View Trip & Safety
                <ChevronRight className="size-4" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Past trips */}
        <div>
          <h2
            className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3"
          >
            Past Trips
          </h2>
          <div className="space-y-3">
            <PastTripCard
              name="Arjun Desai"
              city="Vadodara"
              date="Aug 2026"
              rating={5}
              avatarColor="from-indigo-bandhani to-copper"
            />
            <PastTripCard
              name="Fatima Sheikh"
              city="Bhuj"
              date="Jul 2026"
              rating={5}
              avatarColor="from-copper to-terracotta"
            />
          </div>
        </div>

        {/* New trip CTA */}
        <Button
          onClick={onStartMatch}
          variant="outline"
          className="w-full mt-5 border-terracotta/40 text-terracotta hover:bg-terracotta/10 press-effect"
          size="lg"
        >
          <Sparkles className="size-4" />
          Plan a New Trip
        </Button>
      </div>
    </div>
  )
}

function PastTripCard({
  name,
  city,
  date,
  rating,
  avatarColor,
}: {
  name: string
  city: string
  date: string
  rating: number
  avatarColor: string
}) {
  return (
    <Card className="border-border/60 card-hover">
      <CardContent className="flex gap-3 items-center p-3.5">
        <div
          className={`size-10 rounded-xl bg-gradient-to-br ${avatarColor} flex items-center justify-center text-sm font-bold text-white shrink-0`}
          style={{ fontFamily: "var(--font-display)" }}
        >
          {name.split(" ").map((n) => n[0]).join("")}
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="text-sm font-semibold">{name}</h4>
          <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
            <span className="flex items-center gap-1">
              <MapPin className="size-3" />
              {city}
            </span>
            <span>· {date}</span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs">
          <Star className="size-3 fill-saffron text-saffron" />
          <span className="font-medium">{rating}.0</span>
        </div>
      </CardContent>
    </Card>
  )
}
