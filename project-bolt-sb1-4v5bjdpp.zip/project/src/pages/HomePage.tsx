import { useState } from "react"
import { Sparkles, MapPin, ChevronRight, Compass, Shield, Users } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { cities, type City } from "@/lib/data/cities"
import { useScrollReveal } from "@/hooks/use-scroll-reveal"
import type { PageId } from "@/components/ilahi/BottomNav"

interface HomePageProps {
  onNavigate: (page: PageId) => void
  onSelectCity: (cityId: string) => void
  onStartMatch: () => void
}

export function HomePage({ onNavigate, onSelectCity, onStartMatch }: HomePageProps) {
  const [featuredIdx] = useState(0)
  const featured = cities[featuredIdx]
  const revealRef = useScrollReveal()
  const revealRef2 = useScrollReveal()

  return (
    <div className="bottom-nav-pad">
      <TopBar showNotifications transparent />

      {/* Hero with parallax backdrop */}
      <section className="relative overflow-hidden -mt-1">
        <div
          className="absolute inset-0 bg-gradient-to-br from-indigo-bandhani via-terracotta to-saffron opacity-90 animate-backdrop-drift"
          style={{ backgroundSize: "110%" }}
        />
        <div className="absolute inset-0 bandhani-pattern opacity-40" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />

        <div className="relative px-5 pt-8 pb-10">
          <div className="animate-reveal-up">
            <Badge
              variant="outline"
              className="mb-3 border-white/30 text-white/90 bg-white/10 backdrop-blur-sm"
            >
              <Sparkles className="size-3 mr-1" />
              AI-Powered Local Discovery
            </Badge>
          </div>

          <h1
            className="text-3xl font-bold text-white leading-tight tracking-tight animate-reveal-up delay-100"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Meet Gujarat<br />
            through its <em className="not-italic text-saffron">people</em>.
          </h1>

          <p className="mt-3 text-sm text-white/80 leading-relaxed max-w-[280px] animate-reveal-up delay-200">
            Verified locals, hidden craft villages, and itineraries built by people who actually live there — not algorithms guessing.
          </p>

          <div className="mt-5 flex gap-2 animate-reveal-up delay-300">
            <Button
              onClick={onStartMatch}
              className="bg-white text-indigo-bandhani hover:bg-white/90 font-semibold press-effect"
              size="lg"
            >
              <Sparkles className="size-4" />
              Find My Local
            </Button>
            <Button
              variant="outline"
              onClick={() => onNavigate("explore")}
              className="border-white/30 text-white hover:bg-white/10 hover:text-white press-effect"
              size="lg"
            >
              <Compass className="size-4" />
              Explore
            </Button>
          </div>
        </div>
      </section>

      {/* Stats strip */}
      <section className="px-5 -mt-4 relative z-10">
        <Card className="card-hover border-border/60 shadow-md">
          <CardContent className="grid grid-cols-3 gap-2 py-4">
            <StatBlock value="6" label="Cities" />
            <StatBlock value="240+" label="Verified Locals" />
            <StatBlock value="94%" label="Match Score" />
          </CardContent>
        </Card>
      </section>

      {/* Featured city */}
      <section className="px-5 mt-7">
        <div className="flex items-center justify-between mb-3">
          <h2
            className="text-lg font-semibold"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Featured This Week
          </h2>
          <ChevronRight className="size-4 text-muted-foreground" />
        </div>

        <div
          ref={revealRef}
          className="scroll-hidden scroll-hidden-scale"
        >
          <CityHeroCard city={featured} onClick={() => onSelectCity(featured.id)} />
        </div>
      </section>

      {/* All cities grid */}
      <section className="px-5 mt-7">
        <h2
          className="text-lg font-semibold mb-3"
          style={{ fontFamily: "var(--font-display)" }}
        >
          All Destinations
        </h2>
        <div className="grid grid-cols-2 gap-3">
          {cities.map((city, idx) => (
            <CityCard
              key={city.id}
              city={city}
              index={idx}
              onClick={() => onSelectCity(city.id)}
            />
          ))}
        </div>
      </section>

      {/* How ILAHI works */}
      <section ref={revealRef2} className="scroll-hidden px-5 mt-8">
        <h2
          className="text-lg font-semibold mb-4"
          style={{ fontFamily: "var(--font-display)" }}
        >
          How ILAHI Works
        </h2>
        <div className="space-y-3">
          <StepCard
            num="1"
            icon={Compass}
            title="Tell us your vibe"
            desc="Destination, dates, budget, interests — what you actually care about."
          />
          <StepCard
            num="2"
            icon={Users}
            title="Get matched with a local"
            desc="Our AI scoring pairs you with a verified local who shares your interests."
          />
          <StepCard
            num="3"
            icon={Shield}
            title="Book & travel safely"
            desc="Escrow-protected payments, live trip sharing, and SOS for peace of mind."
          />
        </div>
      </section>

      {/* Trust pillars */}
      <section className="px-5 mt-8">
        <div className="rounded-2xl bg-gradient-to-br from-indigo-bandhani/10 to-terracotta/10 border border-border/60 p-4">
          <h3
            className="text-base font-semibold mb-2"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Why ILAHI is different
          </h3>
          <div className="space-y-2 text-sm text-muted-foreground">
            <div className="flex gap-2">
              <span className="text-terracotta font-bold">·</span>
              <span>Human connection, not hotel-booking transactions</span>
            </div>
            <div className="flex gap-2">
              <span className="text-terracotta font-bold">·</span>
              <span>Hidden culture beyond the top-10 tourist list</span>
            </div>
            <div className="flex gap-2">
              <span className="text-terracotta font-bold">·</span>
              <span>Safety-first: verified locals, escrow, live sharing</span>
            </div>
            <div className="flex gap-2">
              <span className="text-terracotta font-bold">·</span>
              <span>Local youth earn from their own knowledge</span>
            </div>
          </div>
        </div>
      </section>

      <div className="h-4" />
    </div>
  )
}

function StatBlock({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <div
        className="text-xl font-bold text-terracotta"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">
        {label}
      </div>
    </div>
  )
}

function CityHeroCard({ city, onClick }: { city: City; onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full text-left press-effect">
      <div className="relative overflow-hidden rounded-2xl border border-border/60 card-hover">
        <div
          className={`h-44 bg-gradient-to-br ${city.heroGradient} relative`}
        >
          <div className="absolute inset-0 bandhani-pattern opacity-30" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4">
            <Badge
              variant="outline"
              className="border-white/30 text-white/90 bg-white/10 backdrop-blur-sm mb-1.5"
            >
              <MapPin className="size-3 mr-1" />
              {city.region}
            </Badge>
            <h3
              className="text-2xl font-bold text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              {city.name}
            </h3>
            <p className="text-xs text-white/80 mt-0.5">{city.tagline}</p>
          </div>
        </div>
        <div className="p-4 bg-card">
          <p className="text-sm text-muted-foreground line-clamp-2 leading-relaxed">
            {city.intro}
          </p>
          <div className="flex items-center gap-1.5 mt-3 flex-wrap">
            {city.vibe.slice(0, 3).map((v) => (
              <Badge key={v} variant="secondary" className="text-[10px]">
                {v}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </button>
  )
}

function CityCard({
  city,
  index,
  onClick,
}: {
  city: City
  index: number
  onClick: () => void
}) {
  return (
    <button
      onClick={onClick}
      className="text-left press-effect animate-stagger-in"
      style={{ animationDelay: `${index * 80}ms` }}
    >
      <div className="relative overflow-hidden rounded-xl border border-border/60 card-hover h-32">
        <div className={`absolute inset-0 bg-gradient-to-br ${city.heroGradient}`} />
        <div className="absolute inset-0 bandhani-pattern opacity-25" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute bottom-2 left-3 right-3">
          <h3
            className="text-base font-bold text-white leading-tight"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {city.name}
          </h3>
          <p className="text-[10px] text-white/70 truncate">{city.tagline}</p>
        </div>
        <div className="absolute top-2 right-2">
          <Badge
            variant="outline"
            className="border-white/30 text-white/80 bg-black/20 backdrop-blur-sm text-[9px]"
          >
            {city.bestTime}
          </Badge>
        </div>
      </div>
    </button>
  )
}

function StepCard({
  num,
  icon: Icon,
  title,
  desc,
}: {
  num: string
  icon: typeof Compass
  title: string
  desc: string
}) {
  return (
    <div className="flex gap-3 items-start rounded-xl border border-border/60 bg-card p-3.5 card-hover">
      <div className="size-10 rounded-xl bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center shrink-0">
        <Icon className="size-5 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="text-[10px] font-bold text-terracotta/60">STEP {num}</span>
        </div>
        <h4 className="text-sm font-semibold mt-0.5">{title}</h4>
        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{desc}</p>
      </div>
    </div>
  )
}
