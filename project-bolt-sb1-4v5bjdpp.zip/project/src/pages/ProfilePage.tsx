import { User, Star, MapPin, Heart, Settings, HelpCircle, LogOut, ChevronRight, Award, Compass } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface ProfilePageProps {
  onBecomeGuide: () => void
}

export function ProfilePage({ onBecomeGuide }: ProfilePageProps) {
  return (
    <div className="bottom-nav-pad">
      <TopBar title="Profile" />

      <div className="px-5 pt-4">
        {/* Profile header */}
        <div className="flex flex-col items-center mb-5">
          <div className="size-20 rounded-2xl bg-gradient-to-br from-terracotta to-saffron flex items-center justify-center text-3xl font-bold text-white" style={{ fontFamily: "var(--font-display)" }}>
            A
          </div>
          <h2
            className="text-xl font-bold mt-3"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Ananya Sharma
          </h2>
          <p className="text-sm text-muted-foreground">ananya@email.com</p>
          <div className="flex gap-2 mt-2">
            <Badge variant="outline" className="border-terracotta text-terracotta text-[10px]">
              <Award className="size-3 mr-1" />
              Explorer Level
            </Badge>
            <Badge variant="secondary" className="text-[10px]">
              <MapPin className="size-3 mr-1" />
              Mumbai, India
            </Badge>
          </div>
        </div>

        {/* Stats */}
        <Card className="border-border/60 mb-4">
          <CardContent className="grid grid-cols-3 gap-2 py-4">
            <StatItem value="3" label="Trips" />
            <StatItem value="2" label="Cities" />
            <StatItem value="4.9" label="Rating" icon={Star} />
          </CardContent>
        </Card>

        {/* Become a Guide CTA */}
        <button
          onClick={onBecomeGuide}
          className="w-full flex items-center gap-3 rounded-xl bg-gradient-to-r from-indigo-bandhani to-terracotta p-4 text-left press-effect mb-4 card-hover"
        >
          <div className="size-10 rounded-lg bg-white/20 flex items-center justify-center shrink-0">
            <Compass className="size-5 text-white" />
          </div>
          <div className="flex-1">
            <h3
              className="text-sm font-bold text-white"
              style={{ fontFamily: "var(--font-display)" }}
            >
              Become a Local Guide
            </h3>
            <p className="text-[11px] text-white/80 mt-0.5">
              Share your knowledge. Earn from your city.
            </p>
          </div>
          <ChevronRight className="size-4 text-white/70" />
        </button>

        {/* Menu items */}
        <div className="space-y-2">
          <MenuItem icon={Heart} label="Saved Experiences" />
          <MenuItem icon={MapPin} label="Travel History" />
          <MenuItem icon={Settings} label="Account Settings" />
          <MenuItem icon={HelpCircle} label="Help & Support" />
          <MenuItem icon={LogOut} label="Sign Out" danger />
        </div>

        {/* About */}
        <div className="mt-6 text-center">
          <p className="text-[10px] text-muted-foreground">
            ILAHI · Team EKAGRA · SIH 2026
          </p>
          <p className="text-[10px] text-muted-foreground/60 mt-1">
            PS ID: SIH2026202 · Travel & Tourism
          </p>
        </div>
      </div>
    </div>
  )
}

function StatItem({ value, label, icon: Icon }: { value: string; label: string; icon?: typeof Star }) {
  return (
    <div className="text-center">
      <div
        className="text-xl font-bold text-terracotta flex items-center justify-center gap-1"
        style={{ fontFamily: "var(--font-display)" }}
      >
        {Icon && <Icon className="size-3.5 fill-saffron text-saffron" />}
        {value}
      </div>
      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">{label}</div>
    </div>
  )
}

function MenuItem({
  icon: Icon,
  label,
  danger,
}: {
  icon: typeof User
  label: string
  danger?: boolean
}) {
  return (
    <button className="w-full flex items-center gap-3 rounded-xl border border-border/60 bg-card p-3.5 card-hover press-effect">
      <div
        className={`size-9 rounded-lg flex items-center justify-center ${
          danger ? "bg-destructive/10" : "bg-muted"
        }`}
      >
        <Icon className={`size-4 ${danger ? "text-destructive" : "text-muted-foreground"}`} />
      </div>
      <span className={`flex-1 text-left text-sm font-medium ${danger ? "text-destructive" : ""}`}>
        {label}
      </span>
      {!danger && <ChevronRight className="size-4 text-muted-foreground" />}
    </button>
  )
}
