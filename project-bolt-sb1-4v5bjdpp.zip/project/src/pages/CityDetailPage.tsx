import { MapPin, Clock, Lightbulb, Sparkles, BookOpen, Gem } from "lucide-react"
import { TopBar } from "@/components/ilahi/TopBar"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getCityById } from "@/lib/data/cities"
import { useScrollReveal } from "@/hooks/use-scroll-reveal"

interface CityDetailPageProps {
  cityId: string
  onBack: () => void
  onStartMatch: (cityId: string) => void
}

export function CityDetailPage({ cityId, onBack, onStartMatch }: CityDetailPageProps) {
  const city = getCityById(cityId)
  const revealRef = useScrollReveal()
  const revealRef2 = useScrollReveal()

  if (!city) {
    return (
      <div className="p-8 text-center">
        <p className="text-muted-foreground">City not found.</p>
        <Button onClick={onBack} className="mt-4">Go back</Button>
      </div>
    )
  }

  return (
    <div className="bottom-nav-pad">
      <TopBar showBack onBack={onBack} transparent />

      {/* Hero */}
      <section className="relative overflow-hidden -mt-1">
        <div className={`absolute inset-0 bg-gradient-to-br ${city.heroGradient} animate-backdrop-drift`} />
        <div className="absolute inset-0 bandhani-pattern opacity-30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />

        <div className="relative px-5 pt-6 pb-8">
          <Badge
            variant="outline"
            className="border-white/30 text-white/90 bg-white/10 backdrop-blur-sm mb-2 animate-reveal-up"
          >
            <MapPin className="size-3 mr-1" />
            {city.region}
          </Badge>
          <h1
            className="text-3xl font-bold text-white animate-reveal-up delay-100"
            style={{ fontFamily: "var(--font-display)" }}
          >
            {city.name}
          </h1>
          <p className="text-sm text-white/80 mt-1 animate-reveal-up delay-200">
            {city.tagline}
          </p>

          <div className="flex gap-1.5 mt-3 flex-wrap animate-reveal-up delay-300">
            {city.vibe.map((v) => (
              <Badge
                key={v}
                variant="outline"
                className="border-white/30 text-white/80 bg-white/10 backdrop-blur-sm text-[10px]"
              >
                {v}
              </Badge>
            ))}
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="px-5 -mt-2">
        <p className="text-sm leading-relaxed text-foreground/80 animate-reveal-up">
          {city.intro}
        </p>
      </section>

      {/* Local tip callout */}
      <section className="px-5 mt-4">
        <div className="rounded-xl bg-gradient-to-r from-saffron/15 to-terracotta/10 border border-saffron/30 p-3.5">
          <div className="flex gap-2.5 items-start">
            <div className="size-8 rounded-lg bg-saffron/20 flex items-center justify-center shrink-0">
              <Lightbulb className="size-4 text-saffron" />
            </div>
            <div>
              <p className="text-[10px] font-bold uppercase tracking-wide text-saffron">
                Local Tip
              </p>
              <p className="text-sm text-foreground/90 mt-0.5 leading-relaxed">
                {city.localTip}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Tabs: Hidden Gems / Cultural Notes */}
      <section className="px-5 mt-5">
        <Tabs defaultValue="gems">
          <TabsList className="w-full">
            <TabsTrigger value="gems" className="flex-1">
              <Gem className="size-3.5 mr-1.5" />
              Hidden Gems
            </TabsTrigger>
            <TabsTrigger value="culture" className="flex-1">
              <BookOpen className="size-3.5 mr-1.5" />
              Culture
            </TabsTrigger>
          </TabsList>

          <TabsContent value="gems" className="mt-3 space-y-3">
            <div ref={revealRef} className="scroll-hidden space-y-3">
              {city.hiddenGems.map((gem, idx) => (
                <Card
                  key={gem.name}
                  className="border-border/60 card-hover animate-stagger-in"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <CardContent className="flex gap-3 p-3.5">
                    <div className="size-12 rounded-xl bg-muted flex items-center justify-center text-2xl shrink-0">
                      {gem.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4
                        className="text-sm font-semibold"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {gem.name}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                        {gem.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="culture" className="mt-3 space-y-3">
            <div ref={revealRef2} className="scroll-hidden space-y-3">
              {city.culturalNotes.map((note, idx) => (
                <Card
                  key={note.title}
                  className="border-border/60 card-hover animate-stagger-in"
                  style={{ animationDelay: `${idx * 100}ms` }}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="size-6 rounded-lg bg-indigo-bandhani/15 flex items-center justify-center">
                        <BookOpen className="size-3 text-indigo-bandhani" />
                      </div>
                      <h4
                        className="text-sm font-semibold"
                        style={{ fontFamily: "var(--font-display)" }}
                      >
                        {note.title}
                      </h4>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {note.detail}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </section>

      {/* Best time */}
      <section className="px-5 mt-4">
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="size-4 text-terracotta" />
          <span>Best time to visit: <strong className="text-foreground">{city.bestTime}</strong></span>
        </div>
      </section>

      {/* CTA */}
      <section className="px-5 mt-6">
        <Button
          onClick={() => onStartMatch(city.id)}
          className="w-full bg-gradient-to-r from-terracotta to-saffron text-white font-semibold press-effect"
          size="lg"
        >
          <Sparkles className="size-4" />
          Find a Local in {city.name}
        </Button>
        <p className="text-[11px] text-muted-foreground text-center mt-2">
          Get matched with a verified local who knows {city.name}'s hidden side
        </p>
      </section>

      <div className="h-4" />
    </div>
  )
}
