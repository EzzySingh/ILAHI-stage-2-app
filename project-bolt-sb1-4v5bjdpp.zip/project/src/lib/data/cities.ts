export interface HiddenGem {
  name: string
  description: string
  icon: string
}

export interface CulturalNote {
  title: string
  detail: string
}

export interface City {
  id: string
  name: string
  region: string
  tagline: string
  intro: string
  hiddenGems: HiddenGem[]
  culturalNotes: CulturalNote[]
  localTip: string
  bestTime: string
  vibe: string[]
  heroGradient: string
  heroGradientDark: string
  accentColor: string
  imageKeywords: string
}

export const cities: City[] = [
  {
    id: "ahmedabad",
    name: "Ahmedabad",
    region: "Central Gujarat",
    tagline: "Pols, Kites & Midnight Manek",
    intro:
      "Beyond the Sabarmati Ashram that every itinerary leads you to, Ahmedabad breathes through its ancient pol neighbourhoods — labyrinthine lanes where 600-year-old haveli doors still open for family puja, and where the scent of fafda frying at sunrise mingles with sandalwood incense. This is a UNESCO World Heritage City that lives, not just displays itself.",
    hiddenGems: [
      {
        name: "Pol Architecture Walks",
        description:
          "Duck into Khadia or Dhalgarwad at 7 AM. Carved wooden façades, secret 'khancho' communal courts, and families who'll invite you in for chai if you ask politely.",
        icon: "🏛️",
      },
      {
        name: "Dada Hari Vav Stepwell",
        description:
          "A 15th-century stepwell tucked behind a quiet lane in Asarwa — five storeys of carved geometric stone descending to cold groundwater. Almost always uncrowded before 9 AM.",
        icon: "🌀",
      },
      {
        name: "Manek Chowk Night Food",
        description:
          "The jewellery market closes at 8 PM, then street cooks claim the square. By 10 PM it's Ahmedabad's most electric open-air food court — dal baati, pav bhaji, falooda, and ice-cream vendors competing in chaos.",
        icon: "🌙",
      },
      {
        name: "Kite Museum",
        description:
          "A small, obsessively curated museum near Sanskar Kendra with kites from 35 countries. The caretaker will unroll hand-painted Uttarayan kites from the 1970s if you express genuine interest.",
        icon: "🪁",
      },
    ],
    culturalNotes: [
      {
        title: "Uttarayan — The Sky Becomes a Battlefield",
        detail:
          "On Makar Sankranti (Jan 14–15), Ahmedabad's rooftops become arenas. Manja (glass-coated kite string) can reach 3 km. Locals plan rooftop parties months in advance. As a guest, expect to lose every kite you fly and gain three new friends.",
      },
      {
        title: "Thali Culture & Farsan Obsession",
        detail:
          "Gujarati thali is a statement, not a meal — unlimited refills of 15–20 items. But the real pride is farsan: the snack ecosystem of gathiya, sev, chakli, and chevdo that anchors every home kitchen and every rail platform in the state.",
      },
    ],
    localTip:
      "Early morning pol walk (7–9 AM) before heat and tour groups arrive. Hire a local pol-heritage guide (₹300–500) — they know which doors to knock on.",
    bestTime: "Nov–Feb",
    vibe: ["Heritage", "Food", "Architecture", "Festivals"],
    heroGradient: "from-amber-900/80 via-orange-700/60 to-yellow-600/40",
    heroGradientDark: "from-amber-950/90 via-orange-900/70 to-yellow-900/50",
    accentColor: "oklch(0.75 0.17 62)",
    imageKeywords: "ahmedabad pol architecture heritage stepwell gujarat",
  },
  {
    id: "vadodara",
    name: "Vadodara",
    region: "East Gujarat",
    tagline: "Royal Halls, Fine Art & Parsi Tables",
    intro:
      "Vadodara — Baroda to anyone over 40 — wears its Gaekwad royal legacy lightly. The Maharaja's palace contains one of Asia's finest private art collections, the city's Maharaja Sayajirao University produces artists who show globally, and Navratri garba here has an intensity that makes other cities' celebrations look rehearsed. It's a city of quiet culture that rewards the unhurried.",
    hiddenGems: [
      {
        name: "Laxmi Vilas Palace Lesser Wings",
        description:
          "Everyone photographs the main palace façade. Few walk the interior museum's lesser galleries — the royal hunting trophies, 19th-century European paintings acquired by the progressive Maharaja, and a room of armour that belonged to both Mughal emperors and British officers.",
        icon: "👑",
      },
      {
        name: "EME Temple",
        description:
          "An Indian Army temple built entirely with electronic and mechanical engineering parts — circuit boards as ornamentation, gear-wheel spires, a dome clad in aluminium. Architecturally bizarre, genuinely moving.",
        icon: "⚙️",
      },
      {
        name: "Sayaji Baug Art Gallery",
        description:
          "The state's finest public art collection sits inside a sprawling park that also has a zoo, a toy train, and a planetarium. The gallery gets missed by tourists rushing the zoo. Don't miss the Raja Ravi Varma originals.",
        icon: "🎨",
      },
      {
        name: "Parsi-Gujarati Food Trail",
        description:
          "Vadodara has one of Gujarat's largest Parsi communities. Seek out dhansak (lentil-meat stew), patra ni machhi (fish in chutney steamed in banana leaves), and the hybrid Parsi-Gujarati thali at select community-adjacent restaurants.",
        icon: "🍛",
      },
    ],
    culturalNotes: [
      {
        title: "MSU Faculty of Fine Arts",
        detail:
          "The Maharaja Sayajirao University's art faculty has produced India's most globally recognised painters and sculptors for six decades. During exhibitions (Oct–Feb), the faculty opens its studios. Walking in feels like entering a working Bauhaus.",
      },
      {
        title: "Navratri Garba — The Real Thing",
        detail:
          "Vadodara garba circles can run past midnight, nine nights straight, with 5,000 dancers in a single ground. The footwork complexity and the competitive spirit between neighbourhoods is nothing like the social-media version of Navratri. Ask a local which talav (community ground) is the best this year.",
      },
    ],
    localTip:
      "Rent a bicycle at the park gate (₹20/hr) for Sayaji Baug — it's massive and the paths are wide. Visit before 10 AM in summer, the tree cover runs out after that.",
    bestTime: "Oct–Mar",
    vibe: ["Royal Heritage", "Art", "Culture", "Food"],
    heroGradient: "from-purple-900/80 via-violet-700/60 to-indigo-600/40",
    heroGradientDark: "from-purple-950/90 via-violet-900/70 to-indigo-900/50",
    accentColor: "oklch(0.55 0.14 264)",
    imageKeywords: "vadodara baroda palace art gallery gujarat royal heritage",
  },
  {
    id: "bhuj",
    name: "Bhuj",
    region: "Kutch",
    tagline: "Craft Villages, Mirror Work & White Rann Nights",
    intro:
      "Bhuj is the gateway to Kutch — a land so alien it's been compared to the surface of Mars, yet so human it has produced some of India's most intricate textile arts. The town itself rebuilt after the 2001 earthquake with a defiant creative energy. But Kutch's soul lives in its villages: Ajrakhpur where block printers still use 400-year-old wooden stamps, Bhujodi where every second home is a weaving shed.",
    hiddenGems: [
      {
        name: "Ajrakhpur & Bhujodi Villages",
        description:
          "Two kilometres apart, entirely different craft traditions. Ajrakhpur is all geometric indigo block-printing on cotton. Bhujodi weaves shawls with intricate supplementary-weft patterns that take a month per piece. Both villages welcome visitors directly into artisan homes — no ticket, just respect.",
        icon: "🧵",
      },
      {
        name: "Kutchi Folk Music Circles",
        description:
          "Manganiyar and Langha musicians from Rajasthan cross into Kutch for winter weddings and festivals. Ask your local contact if any 'bhajan baithaks' are happening — informal evening music circles that can run until 2 AM under open sky.",
        icon: "🎵",
      },
      {
        name: "Mirror-Work Embroidery Workshops",
        description:
          "Mutwa and Rabari communities embroider with tiny mirrors (abhala bharat) stitched into vibrant cloth. Some family workshops in Bhuj old city accept half-day students. You leave with a small piece you made yourself and an understanding of why a shawl costs ₹12,000.",
        icon: "✨",
      },
      {
        name: "Rann Off-Season Stargazing",
        description:
          "During Rann Utsav (Nov–Feb) the White Rann is busy. Visit in October — before the official season — when the salt flat is empty, silent, and the Milky Way is visible without any light pollution for 150 km in every direction.",
        icon: "⭐",
      },
    ],
    culturalNotes: [
      {
        title: "Kutchi Embroidery as Identity Language",
        detail:
          "Every Kutchi community — Rabari, Mutwa, Ahir, Sodha — has a distinct embroidery vocabulary: specific stitch types, motif patterns, and colour combinations that identify the maker's community, marital status, and sometimes her village. What looks decorative is actually a dense visual text.",
      },
      {
        title: "Ajrakh Printing — Living Chemistry",
        detail:
          "Natural-dye Ajrakh involves 16 distinct steps over 21 days, using indigo fermentation vats, pomegranate rind mordants, and mud resist. The master printers (Khatri community) measure dye strength by texture and smell, not measurement. The knowledge is transmitted only within family lineages.",
      },
    ],
    localTip:
      "Morning craft-village visits (8–11 AM) before artisans take midday breaks. Carry cash for home workshops — UPI coverage in villages is patchy. Bargaining in front of artisans for their own work is considered deeply rude; the workshop price is the price.",
    bestTime: "Nov–Feb",
    vibe: ["Craft", "Desert", "Art", "Stargazing"],
    heroGradient: "from-red-900/80 via-orange-800/60 to-amber-700/40",
    heroGradientDark: "from-red-950/90 via-orange-950/70 to-amber-900/50",
    accentColor: "oklch(0.62 0.11 55)",
    imageKeywords: "bhuj kutch white rann salt flat desert gujarat craft embroidery",
  },
  {
    id: "junagadh",
    name: "Junagadh",
    region: "Saurashtra",
    tagline: "Girnar's Sacred Climb & Nawabi Street Food",
    intro:
      "Junagadh sits at the foot of Mount Girnar — a 3,666-step sacred pilgrimage that Hindus, Jains, and Nath Siddha yogis have been climbing for 2,000 years. The town below carries layers: Ashokan rock edicts from 250 BCE, Nawabi-era hunting lodges, Buddhist caves from the 3rd century, and a street food culture built around fresh peanuts and dabeli that is arguably the finest in Saurashtra.",
    hiddenGems: [
      {
        name: "Girnar Night Trek to Datar Hill",
        description:
          "The most atmospheric version of Girnar is leaving Junagadh at 2 AM with a torch, reaching the summit temples at sunrise, and continuing to Datar Hill — where a Sufi dargah sits next to a Nath Siddha shrine next to a Jain temple. Three faiths, one mountaintop, total silence except for wind and distant prayers.",
        icon: "🌄",
      },
      {
        name: "Uparkot Fort Stepwells & Buddhist Caves",
        description:
          "Inside Uparkot Fort, two of the finest stepwells in Gujarat (Adi Chadi Vav and Navghan Kuvo) descend 40 metres in perfect geometric spirals. Behind the fort's east wall, 3rd-century Buddhist caves with carved meditation halls are almost always empty.",
        icon: "🏯",
      },
      {
        name: "Nawabi-Era Street Food Circuit",
        description:
          "The Junagadh Nawabs left behind a food culture that combines Kathiawari vegetarian with Muslim meat traditions. Seek out: kesar mango shrikhand (May–June), fresh peanut chikki made on the pavement, and the original dabeli — stuffed potato roll that Junagadh claims to have invented.",
        icon: "🥜",
      },
      {
        name: "Sasan Gir Community Homestays",
        description:
          "Thirty km from Junagadh, Sasan Gir is the last Asiatic lion habitat. Beyond the jeep safari, the Maldhari tribal community — who live inside the sanctuary and have coexisted with lions for 150 years — run basic homestays that give a fundamentally different view of wildlife.",
        icon: "🦁",
      },
    ],
    culturalNotes: [
      {
        title: "Girnar Parikrama — Barefoot Circumambulation",
        detail:
          "Every Kartik Purnima (Nov–Dec), around 5 lakh pilgrims walk the 36 km barefoot circuit around Mount Girnar over five days. The path passes through forest, river crossings, and a dozen shrines. Participation is open to all faiths and to non-Hindu walkers who approach with genuine respect.",
      },
      {
        title: "Ashokan Edicts in Magadhi Prakrit",
        detail:
          "The rock inscriptions at Uparkot Fort's entrance — carved in 250 BCE — are Ashoka's original Magadhi Prakrit edicts, unweathered enough to still be readable. A 15th-century Indo-Islamic overlay was added by Mahomed Begada of Gujarat. Three imperial civilisations, one rock face.",
      },
    ],
    localTip:
      "Wear grippy shoes (not slippers) for Girnar — the steps are uneven sandstone, slippery in early morning dew. Start the night trek by 3 AM to be above the treeline for sunrise. The Junagadh Municipal Corporation posts current lion sightings on their notice board near the main gate.",
    bestTime: "Oct–Mar",
    vibe: ["Trekking", "Pilgrimage", "Wildlife", "History"],
    heroGradient: "from-green-900/80 via-emerald-800/60 to-teal-700/40",
    heroGradientDark: "from-green-950/90 via-emerald-950/70 to-teal-900/50",
    accentColor: "oklch(0.5 0.13 160)",
    imageKeywords: "junagadh girnar mountain pilgrimage gujarat fort stepwell",
  },
  {
    id: "dwarka",
    name: "Dwarka",
    region: "West Gujarat",
    tagline: "Pilgrimage Coast, Tidal Islands & Fishing Dawns",
    intro:
      "Dwarka sits at the westernmost tip of Gujarat's coast, where the Arabian Sea meets the Gulf of Kutch. One of Hinduism's four sacred dhams, it draws pilgrims who come to see the Jagat Mandir — a 72-metre spire built and rebuilt at the same spot for 2,500 years on the edge of the sea. But beyond the temple queues, Dwarka has a fishing economy, a tidal island accessible by boat, and a coastline empty enough to walk for hours without company.",
    hiddenGems: [
      {
        name: "Fishing Village Life at Okha Port",
        description:
          "Okha, 30 km from Dwarka, is the working port from which boats leave for Bet Dwarka island. The fish auction at 6 AM is one of the most kinetic scenes in coastal Gujarat — pomfret, shark, and crab sorted and sold in minutes in a language of gestures and shouts.",
        icon: "⚓",
      },
      {
        name: "Bet Dwarka Boat Culture",
        description:
          "The island of Bet Dwarka is reached by a 15-minute boat crossing from Okha. The island's secondary temple of Bet Dwarka is less crowded than the main Jagat Mandir and the crossing itself — on wooden boats piloted by fishermen who double as boatmen — is the experience.",
        icon: "⛵",
      },
      {
        name: "Nageshwar Coastal Walk",
        description:
          "The road from Dwarka to Nageshwar Jyotirlinga passes empty beaches and a coastline that faces northwest — one of the few places in India where you can watch the sun set directly into the sea, with no islands or sandbanks obscuring the horizon.",
        icon: "🌅",
      },
      {
        name: "Rukmini Devi Temple",
        description:
          "Two kilometres outside Dwarka, a small 12th-century temple to Rukmini (Krishna's chief consort) with exquisite Chalukya carvings. It's rarely busy and the priests are often willing to explain the iconographic programme of each wall panel.",
        icon: "🏛️",
      },
    ],
    culturalNotes: [
      {
        title: "Jagat Mandir Flag — Changed Four Times Daily",
        detail:
          "The Jagat Mandir's distinctive 78-foot spire flies a flag that is changed at each of the four daily puja cycles (dawn, noon, dusk, night). The flag change ceremony is done by a hereditary family of priests who have held this specific ritual role for generations. Watching a flag change at sunset is the most moving version of the pilgrimage.",
      },
      {
        title: "Bet Dwarka Barter Economy",
        detail:
          "The island still operates a partially informal economy where fishing families trade directly with pilgrims — dried fish, cowrie shells, and temple offerings exchanging hands outside any formal market structure. The coin is trust rather than price negotiation.",
      },
    ],
    localTip:
      "Check the tide table before planning the Bet Dwarka crossing — the channel becomes rough in afternoon wind. Morning (7–9 AM) gives smooth water and returns before heat. The Jagat Mandir queue at 5 AM puja is long but moves fast and the atmosphere is electric.",
    bestTime: "Oct–Mar",
    vibe: ["Pilgrimage", "Coastal", "Fishing Culture", "Temples"],
    heroGradient: "from-blue-900/80 via-cyan-800/60 to-sky-700/40",
    heroGradientDark: "from-blue-950/90 via-cyan-950/70 to-sky-900/50",
    accentColor: "oklch(0.6 0.13 220)",
    imageKeywords: "dwarka coastal pilgrimage gujarat temple sea fishing boats",
  },
  {
    id: "diu",
    name: "Diu",
    region: "Union Territory",
    tagline: "Portuguese Walls, Fusion Tables & Empty Beaches",
    intro:
      "Diu is a small island off the southern tip of Saurashtra that Portugal held from 1535 to 1961 — 426 years that left a distinct architectural and culinary fingerprint. The fort at the island's eastern tip is one of the finest Portuguese military structures in the subcontinent. The town's churches sit next to Hindu temples. The surnames are hyphenated. The food is neither Gujarati nor Goan but its own particular fusion: Gujarati spices on fish that Catholic fishermen caught for a Portuguese administration.",
    hiddenGems: [
      {
        name: "Diu Fort Colonial Circuit",
        description:
          "The eastern fortress circuit takes two hours and reveals layers: Portuguese cannon embrasures, a Mughal-period mosque built inside the fort's walls, an Indian Navy signals station (now decommissioned), and sea-facing bastions where the Arabian Sea crashes 30 metres below. Almost always uncrowded.",
        icon: "🏰",
      },
      {
        name: "Naida Caves",
        description:
          "Quarried by the Portuguese for fort-building stone, the cave network left behind an accidental cathedral of light shafts, mossy walls, and Gothic-arched cavities. The main cave entrance is 300 metres from the main road. The interior network takes 45 minutes to explore and ends at a natural window over the sea.",
        icon: "🗿",
      },
      {
        name: "Portuguese-Era Churches",
        description:
          "St. Paul's Church in Diu town (now the Museum of Sacred Art) retains its original Baroque carved façade intact — the interior conversion into a museum preserved the altar architecture. The smaller Chapel of Our Lady of Mercy is still a working church with weekly Mass in Portuguese, Gujarati, and English.",
        icon: "⛪",
      },
      {
        name: "Quiet Fishing Beaches",
        description:
          "Nagoa Beach gets all the tourism attention. Chakratirth Beach and Ghoghla Beach (on the mainland side) are quieter, face different tidal patterns, and the fishing boats launch from Ghoghla at 5 AM — a working beach scene that hasn't been staged for visitors.",
        icon: "🏖️",
      },
    ],
    culturalNotes: [
      {
        title: "Fusion Identity on the Table",
        detail:
          "Diu's food doesn't ask you to choose between Gujarati and Portuguese inheritance. The fish curry uses kokum (Gujarati souring agent) and dried shrimp (Portuguese coastal tradition). The bread baked in the morning is a Portuguese pão loaf. The toddy (palm wine) is a direct colonial remnant. The resulting cuisine is one of India's most genuinely syncretic.",
      },
      {
        title: "Mixed Surname Lines",
        detail:
          "Diu's Catholic families carry surnames that are direct transliterations of Gujarati names into Portuguese phonetics — Soares (from Surti?), Dias, Mascarenhas — combined with retained Hindu first names. This 426-year hybridity is visible in the old cemetery's epitaphs and in the conversations of elderly residents who switch between Gujarati and a Portuguese-inflected dialect mid-sentence.",
      },
    ],
    localTip:
      "Hire a bicycle (₹80/day from near the bus stand) — Diu is 40 km² and flat, easily cycled in a day. Visit Diu Fort at sunset when the cannon embrasures frame the western sky. The fort closes at dusk; arrive at 5:30 PM and take position on the western bastion.",
    bestTime: "Oct–Mar",
    vibe: ["Colonial History", "Beaches", "Fusion Food", "Architecture"],
    heroGradient: "from-teal-900/80 via-cyan-800/60 to-blue-700/40",
    heroGradientDark: "from-teal-950/90 via-cyan-950/70 to-blue-900/50",
    accentColor: "oklch(0.55 0.13 190)",
    imageKeywords: "diu fort portuguese colonial india beach gujarat church",
  },
]

export const getCityById = (id: string): City | undefined =>
  cities.find((c) => c.id === id)
