import { createClient } from "@supabase/supabase-js"

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false,
  },
})

export type GuideProfile = {
  id: string
  user_id: string
  full_name: string
  phone: string
  photo_url: string | null
  primary_area: string
  areas_of_expertise: string[] | null
  specialties: string[] | null
  bio: string | null
  availability_preset: string
  is_verified: boolean
  verification_notes: string | null
  credential_url: string | null
  contact_visible: boolean
  profile_completion_pct: number
  created_at: string
  updated_at: string
}

export type GuideAvailability = {
  id: string
  guide_id: string
  day_of_week: number | null
  start_time: string | null
  end_time: string | null
  is_active: boolean
  created_at: string
}
